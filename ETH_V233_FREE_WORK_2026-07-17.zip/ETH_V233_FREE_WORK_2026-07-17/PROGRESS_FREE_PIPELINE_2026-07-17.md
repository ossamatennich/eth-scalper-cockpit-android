# ETH Scalper Cockpit v2.33 — progression gratuite vérifiable

## Statut

- Application : `RESEARCH_ONLY`.
- Intégration Android : interdite (`android_integration_allowed=false`).
- LONA : aucune nouvelle action utilisée ; la suite est entièrement gratuite et locale.
- Rentabilité : aucune déclaration. Les exécutions actuelles sur données synthétiques valident uniquement la mécanique du moteur.

## Corrections techniques produites

### Moteur intraday v2.33

`v233_research_engine.py` implémente :

- régime réellement calculé sur bougies 4 h clôturées ;
- exécution sur bougies 1 h, signal à la clôture et entrée au prochain open ;
- LONG, SHORT et BOTH ;
- stop et objectif à seuil explicite ;
- priorité conservative au stop si stop et objectif sont touchés dans la même bougie ;
- gestion adverse des gaps de stop et absence d'amélioration artificielle sur gap d'objectif ;
- frais et slippage inclus dans le calcul de quantité par risque ;
- plafond de levier, break-even, trailing, durée maximale et cooldown ;
- drawdown, profit factor, espérance en R et Sharpe journalier ;
- 27 paramètres voisins par famille, trois modes et trois familles de stratégie ;
- stress des coûts sur validation uniquement ;
- période finale OOS jamais ouverte sans verrouillage train/validation ; sinon évaluée exactement une fois.

Un défaut supplémentaire a été corrigé pendant les tests : le RSI retournait `NaN` sur une série uniquement haussière ou baissière. Il retourne maintenant correctement 100 ou 0.

### Séparation v2.32.6 flux périmé / risque actif

La correction place `updateObservedSignals(snapshot, now)` avant la garde `V2326_ETH_FEED_STALE` :

- le flux périmé bloque uniquement les nouvelles entrées ;
- la surveillance TP/SL, invalidation et timeout d'un risque déjà actif reste exécutée ;
- le message trompeur « aucune entrée ni sortie simulée » est supprimé.

Artefacts :

- `V2326_STALE_RISK_SEPARATION.patch`
- `apply_v2326_stale_risk_separation.py`
- `apply_v2326_candidate_SAFE_STALE_SEPARATION.py`

## Tests réellement exécutés

Résultat local : **17 tests réussis**.

Les tests couvrent notamment :

- absence de look-ahead 4 h ;
- stop-first sur bougie ambiguë ;
- gaps stop/objectif ;
- LONG et SHORT séparés ;
- BOTH avec les deux sens ;
- quantité bornée par le risque net de frais/slippage ;
- période de warm-up sans entrée ;
- OOS non ouvert sans candidat validé ;
- patch v2.32.6 idempotent ;
- lecture ZIP Binance, checksum et comparaison 4 h native/rééchantillonnée.

`SYNTHETIC_ENGINE_MECHANICS.json` contient les exécutions mécaniques : 14 LONG, 15 SHORT et 29 BOTH. Ces nombres ne constituent pas une preuve de performance de marché.

## Pipeline corpus officiel Binance

`binance_corpus_builder.py` prépare 80 archives publiques :

- 40 archives 1 h ;
- 40 archives 4 h ;
- mensuelles de juillet 2024 à juin 2026 ;
- quotidiennes du 1er au 16 juillet 2026.

Chaque ZIP est contrôlé avec son fichier `.CHECKSUM`, puis le pipeline exige :

- 17 520 bougies 1 h ;
- 4 380 bougies 4 h ;
- aucune bougie manquante ;
- aucun doublon conflictuel ;
- aucune valeur OHLCV invalide ;
- égalité des OHLCV entre 4 h native et 4 h reconstruite depuis 1 h.

Découpage verrouillé :

- train : 17 juillet 2024 — 30 novembre 2025 ;
- validation : 1er décembre 2025 — 28 février 2026 ;
- final OOS intact : 1er mars 2026 — 16 juillet 2026.

## Blocage restant

Le runtime actuel ne possède aucune sortie réseau exploitable pour matérialiser les archives : DNS, connexion directe, passerelle de téléchargement et URL de secours ont été essayés. Le connecteur Binance restitue des bougies dans l'interface, mais ne fournit pas de fichier transférable au moteur local.

Le seul geste restant est d'exécuter `run_free_codespaces.sh` dans un GitHub Codespace gratuit. Le script installe les dépendances libres, télécharge et vérifie le corpus, lance les 17 tests, exécute la recherche et produit `ETH_V233_FREE_RESEARCH_OUTPUT.zip` avec son SHA-256.
