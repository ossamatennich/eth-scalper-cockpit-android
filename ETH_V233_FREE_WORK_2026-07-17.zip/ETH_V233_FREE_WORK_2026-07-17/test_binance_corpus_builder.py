from __future__ import annotations

import hashlib
import io
import zipfile
from pathlib import Path

import pandas as pd

import binance_corpus_builder as builder


def test_checksum_parser_and_zip_reader(tmp_path: Path) -> None:
    csv = b"1721174400000,100,101,99,100.5,10,1721177999999,0,1,0,0,0\n"
    zpath = tmp_path / "sample.zip"
    with zipfile.ZipFile(zpath, "w") as zf:
        zf.writestr("sample.csv", csv)
    frame = builder.read_zip_rows(zpath)
    assert len(frame) == 1
    assert list(frame.columns[:6]) == ["open_time", "open", "high", "low", "close", "volume"]
    digest = hashlib.sha256(zpath.read_bytes()).hexdigest()
    assert builder.parse_checksum(f"{digest}  sample.zip", "sample.zip") == digest


def test_native_4h_crosscheck_matches_resample() -> None:
    idx = pd.date_range(builder.START, periods=8, freq="1h")
    one = pd.DataFrame(
        {
            "open": range(100, 108),
            "high": range(101, 109),
            "low": range(99, 107),
            "close": [v + 0.5 for v in range(100, 108)],
            "volume": 10.0,
        },
        index=idx,
    )
    native = builder.resample_4h(one)
    result = builder.compare_native_and_resampled(native, builder.resample_4h(one))
    assert result["price_mismatch_rows"] == 0
    assert result["volume_mismatch_rows"] == 0
    assert result["native_only"] == 0
    assert result["derived_only"] == 0
