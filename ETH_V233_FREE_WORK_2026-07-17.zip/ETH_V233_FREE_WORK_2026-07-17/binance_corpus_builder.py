#!/usr/bin/env python3
"""Build and audit the ETHUSDT USD-M Futures 1h/4h research corpus.

Free/public source only: https://data.binance.vision
Coverage (UTC, end exclusive): 2024-07-17 00:00 -> 2026-07-17 00:00.
Monthly archives are used through 2026-06; daily archives cover 2026-07-01..16.
Each archive is verified against Binance's sibling .CHECKSUM file.
"""
from __future__ import annotations

import argparse
import calendar
import csv
import hashlib
import io
import json
import re
import time
import zipfile
from dataclasses import asdict, dataclass
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from typing import Iterable
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

import pandas as pd

BASE = "https://data.binance.vision/data/futures/um"
SYMBOL = "ETHUSDT"
START = pd.Timestamp("2024-07-17T00:00:00Z")
END_EXCLUSIVE = pd.Timestamp("2026-07-17T00:00:00Z")
MONTHLY_END = date(2026, 6, 1)
DAILY_START = date(2026, 7, 1)
DAILY_END = date(2026, 7, 16)
COLS = [
    "open_time", "open", "high", "low", "close", "volume", "close_time",
    "quote_volume", "trade_count", "taker_buy_base_volume",
    "taker_buy_quote_volume", "ignore",
]


@dataclass
class ArchiveRecord:
    interval: str
    period: str
    url: str
    file: str
    bytes: int
    sha256: str
    checksum_verified: bool
    rows_raw: int
    retries: int


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def request_bytes(url: str, attempts: int = 5, timeout: int = 90) -> tuple[bytes, int]:
    last: Exception | None = None
    for attempt in range(attempts):
        try:
            req = Request(url, headers={"User-Agent": "ETH-Scalper-Cockpit-Research/2.33"})
            with urlopen(req, timeout=timeout) as response:
                return response.read(), attempt
        except (HTTPError, URLError, TimeoutError, ConnectionError) as exc:
            last = exc
            if isinstance(exc, HTTPError) and exc.code == 404:
                raise
            time.sleep(min(2 ** attempt, 12))
    raise RuntimeError(f"Download failed after {attempts} attempts: {url}: {last}")


def month_starts(start: date, end: date) -> Iterable[date]:
    cur = date(start.year, start.month, 1)
    while cur <= end:
        yield cur
        cur = date(cur.year + (cur.month == 12), 1 if cur.month == 12 else cur.month + 1, 1)


def archive_specs(interval: str) -> list[tuple[str, str]]:
    specs: list[tuple[str, str]] = []
    for d in month_starts(date(2024, 7, 1), MONTHLY_END):
        period = f"{d.year:04d}-{d.month:02d}"
        name = f"{SYMBOL}-{interval}-{period}.zip"
        specs.append((period, f"{BASE}/monthly/klines/{SYMBOL}/{interval}/{name}"))
    cur = DAILY_START
    while cur <= DAILY_END:
        period = cur.isoformat()
        name = f"{SYMBOL}-{interval}-{period}.zip"
        specs.append((period, f"{BASE}/daily/klines/{SYMBOL}/{interval}/{name}"))
        cur += timedelta(days=1)
    return specs


def parse_checksum(text: str, filename: str) -> str:
    matches = re.findall(r"\b[a-fA-F0-9]{64}\b", text)
    if not matches:
        raise ValueError(f"No SHA-256 in checksum for {filename}: {text[:200]!r}")
    return matches[0].lower()


def read_zip_rows(path: Path) -> pd.DataFrame:
    with zipfile.ZipFile(path) as zf:
        names = [n for n in zf.namelist() if not n.endswith("/")]
        if len(names) != 1:
            raise ValueError(f"Expected one CSV in {path.name}, found {names}")
        raw = zf.read(names[0])
    # Some recent Binance archives include a header, older ones do not.
    first = raw.splitlines()[0].decode("utf-8", errors="replace").strip().lower()
    has_header = first.startswith("open_time") or first.startswith("open time")
    df = pd.read_csv(io.BytesIO(raw), header=0 if has_header else None)
    if df.shape[1] < 6:
        raise ValueError(f"Too few columns in {path.name}: {df.shape[1]}")
    df = df.iloc[:, : min(df.shape[1], len(COLS))]
    df.columns = COLS[: df.shape[1]]
    return df


def download_interval(interval: str, root: Path) -> tuple[pd.DataFrame, list[ArchiveRecord]]:
    raw_dir = root / "raw" / interval
    raw_dir.mkdir(parents=True, exist_ok=True)
    frames: list[pd.DataFrame] = []
    records: list[ArchiveRecord] = []
    for period, url in archive_specs(interval):
        filename = url.rsplit("/", 1)[-1]
        path = raw_dir / filename
        checksum_path = raw_dir / f"{filename}.CHECKSUM"
        retries = 0
        if not path.exists():
            payload, retries = request_bytes(url)
            path.write_bytes(payload)
        if not checksum_path.exists():
            checksum_payload, checksum_retries = request_bytes(url + ".CHECKSUM")
            retries += checksum_retries
            checksum_path.write_bytes(checksum_payload)
        actual = sha256_file(path)
        expected = parse_checksum(checksum_path.read_text("utf-8", errors="replace"), filename)
        if actual != expected:
            path.unlink(missing_ok=True)
            raise ValueError(f"SHA-256 mismatch for {filename}: expected {expected}, got {actual}")
        frame = read_zip_rows(path)
        frames.append(frame)
        records.append(ArchiveRecord(
            interval=interval, period=period, url=url, file=str(path.relative_to(root)),
            bytes=path.stat().st_size, sha256=actual, checksum_verified=True,
            rows_raw=len(frame), retries=retries,
        ))
        print(f"OK {interval} {period}: {len(frame)} rows, SHA-256 verified", flush=True)
    return pd.concat(frames, ignore_index=True), records


def normalize(raw: pd.DataFrame, interval: str) -> pd.DataFrame:
    required = ["open_time", "open", "high", "low", "close", "volume"]
    missing = [c for c in required if c not in raw]
    if missing:
        raise ValueError(f"Missing columns: {missing}")
    x = raw[required].copy()
    x["open_time"] = pd.to_datetime(pd.to_numeric(x["open_time"], errors="coerce"), unit="ms", utc=True)
    for c in required[1:]:
        x[c] = pd.to_numeric(x[c], errors="coerce")
    if x.isna().any().any():
        raise ValueError(f"NaN after parsing {interval}: {x.isna().sum().to_dict()}")
    x = x[(x.open_time >= START) & (x.open_time < END_EXCLUSIVE)].copy()
    duplicate_rows = int(x.open_time.duplicated(keep=False).sum())
    if duplicate_rows:
        dup = x[x.open_time.duplicated(keep=False)].sort_values("open_time")
        same = dup.groupby("open_time")[["open", "high", "low", "close", "volume"]].nunique().max(axis=1)
        if (same > 1).any():
            raise ValueError(f"Conflicting duplicate candles in {interval}")
        x = x.drop_duplicates("open_time", keep="last")
    return x.sort_values("open_time").set_index("open_time")


def audit(df: pd.DataFrame, interval: str) -> dict:
    expected_delta = pd.Timedelta(interval)
    expected_index = pd.date_range(START, END_EXCLUSIVE, freq=interval, inclusive="left")
    missing = expected_index.difference(df.index)
    extra = df.index.difference(expected_index)
    ohlc_bad = (
        (df[["open", "high", "low", "close"]] <= 0).any(axis=1)
        | (df.volume < 0)
        | (df.high < df[["open", "close"]].max(axis=1))
        | (df.low > df[["open", "close"]].min(axis=1))
        | (df.high < df.low)
    )
    deltas = df.index.to_series().diff().dropna()
    log_returns = df.close.pct_change().replace([float("inf"), float("-inf")], pd.NA).dropna()
    robust_z = None
    if len(log_returns):
        med = float(log_returns.median())
        mad = float((log_returns - med).abs().median())
        robust_z = ((log_returns - med).abs() / max(1.4826 * mad, 1e-12))
    return {
        "interval": interval,
        "rows": int(len(df)),
        "expected_rows": int(len(expected_index)),
        "start": df.index.min().isoformat() if len(df) else None,
        "end": df.index.max().isoformat() if len(df) else None,
        "timezone": str(df.index.tz),
        "duplicates_after_normalization": int(df.index.duplicated().sum()),
        "missing_count": int(len(missing)),
        "missing_first_50": [v.isoformat() for v in missing[:50]],
        "extra_count": int(len(extra)),
        "extra_first_50": [v.isoformat() for v in extra[:50]],
        "nonstandard_delta_count": int((deltas != expected_delta).sum()),
        "invalid_ohlcv_count": int(ohlc_bad.sum()),
        "zero_volume_count": int((df.volume == 0).sum()),
        "largest_abs_hourly_return_pct": float(log_returns.abs().max() * 100) if len(log_returns) else None,
        "robust_return_outliers_z_gt_20": int((robust_z > 20).sum()) if robust_z is not None else 0,
    }


def resample_4h(one_hour: pd.DataFrame) -> pd.DataFrame:
    return one_hour.resample("4h", label="left", closed="left", origin="epoch").agg(
        open=("open", "first"), high=("high", "max"), low=("low", "min"),
        close=("close", "last"), volume=("volume", "sum"),
    ).dropna()


def compare_native_and_resampled(native: pd.DataFrame, derived: pd.DataFrame) -> dict:
    idx = native.index.intersection(derived.index)
    n = native.loc[idx, ["open", "high", "low", "close", "volume"]]
    d = derived.loc[idx, ["open", "high", "low", "close", "volume"]]
    absdiff = (n - d).abs()
    price_mismatch = (absdiff[["open", "high", "low", "close"]] > 1e-9).any(axis=1)
    volume_tol = 1e-6 + 1e-10 * n.volume.abs()
    volume_mismatch = absdiff.volume > volume_tol
    return {
        "common_rows": int(len(idx)),
        "native_only": int(len(native.index.difference(derived.index))),
        "derived_only": int(len(derived.index.difference(native.index))),
        "price_mismatch_rows": int(price_mismatch.sum()),
        "volume_mismatch_rows": int(volume_mismatch.sum()),
        "max_abs_diff": {c: float(absdiff[c].max()) for c in absdiff},
    }


def write_frame(df: pd.DataFrame, path_base: Path) -> dict:
    out: dict[str, str] = {}
    csv_path = path_base.with_suffix(".csv.gz")
    df.reset_index().to_csv(csv_path, index=False, compression="gzip", float_format="%.12g")
    out["csv_gz"] = str(csv_path)
    out["csv_gz_sha256"] = sha256_file(csv_path)
    try:
        parquet_path = path_base.with_suffix(".parquet")
        df.reset_index().to_parquet(parquet_path, index=False)
        out["parquet"] = str(parquet_path)
        out["parquet_sha256"] = sha256_file(parquet_path)
    except (ImportError, ModuleNotFoundError):
        out["parquet"] = "not_written_pyarrow_missing"
    return out


def build(output: Path) -> dict:
    output.mkdir(parents=True, exist_ok=True)
    manifest_records: list[ArchiveRecord] = []
    raw_1h, records_1h = download_interval("1h", output)
    raw_4h, records_4h = download_interval("4h", output)
    manifest_records.extend(records_1h)
    manifest_records.extend(records_4h)

    one = normalize(raw_1h, "1h")
    four_native = normalize(raw_4h, "4h")
    four_derived = resample_4h(one)
    audit_1h = audit(one, "1h")
    audit_4h = audit(four_native, "4h")
    cross = compare_native_and_resampled(four_native, four_derived)

    critical = (
        audit_1h["missing_count"] or audit_1h["extra_count"] or audit_1h["invalid_ohlcv_count"]
        or audit_4h["missing_count"] or audit_4h["extra_count"] or audit_4h["invalid_ohlcv_count"]
        or cross["price_mismatch_rows"] or cross["volume_mismatch_rows"]
    )
    clean_dir = output / "clean"
    clean_dir.mkdir(exist_ok=True)
    outputs = {
        "1h": write_frame(one, clean_dir / "ETHUSDT_UM_1h_2024-07-17_2026-07-16"),
        "4h_native": write_frame(four_native, clean_dir / "ETHUSDT_UM_4h_native_2024-07-17_2026-07-16"),
        "4h_derived": write_frame(four_derived, clean_dir / "ETHUSDT_UM_4h_derived_2024-07-17_2026-07-16"),
    }
    splits = {
        "development_start": START.isoformat(),
        "train_end_exclusive": "2025-12-01T00:00:00+00:00",
        "validation_start": "2025-12-01T00:00:00+00:00",
        "validation_end_exclusive": "2026-03-01T00:00:00+00:00",
        "final_oos_start": "2026-03-01T00:00:00+00:00",
        "final_oos_end_exclusive": END_EXCLUSIVE.isoformat(),
        "final_oos_policy": "Do not inspect or tune against this period before locking parameters.",
    }
    report = {
        "status": "PASS" if not critical else "FAIL",
        "research_only": True,
        "symbol": SYMBOL,
        "market": "Binance USD-M Futures",
        "start": START.isoformat(),
        "end_exclusive": END_EXCLUSIVE.isoformat(),
        "archive_count": len(manifest_records),
        "archive_manifest": [asdict(r) for r in manifest_records],
        "audit_1h": audit_1h,
        "audit_4h_native": audit_4h,
        "native_vs_resampled_4h": cross,
        "splits": splits,
        "outputs": outputs,
    }
    (output / "CORPUS_AUDIT.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    (output / "SPLITS.json").write_text(json.dumps(splits, indent=2), encoding="utf-8")
    if critical:
        raise SystemExit("Corpus audit FAILED; see CORPUS_AUDIT.json")
    return report


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=Path("ETHUSDT_UM_CORPUS_2024-07-17_2026-07-16"))
    args = parser.parse_args()
    report = build(args.output)
    print(json.dumps({
        "status": report["status"],
        "rows_1h": report["audit_1h"]["rows"],
        "rows_4h": report["audit_4h_native"]["rows"],
        "archive_count": report["archive_count"],
        "output": str(args.output.resolve()),
    }, indent=2))


if __name__ == "__main__":
    main()
