#!/usr/bin/env python3
"""Research-only deterministic multi-timeframe engine for ETH Scalper Cockpit v2.33.

Key guarantees:
- 4h regime values are exposed to a 1h signal only after the 4h candle closed.
- signal at a fully closed 1h candle; market entry/market exit at next 1h open.
- stop and target execute at explicit levels; adverse gaps fill at the gap open.
- if stop and target are both reachable in one candle, stop wins.
- break-even/trailing updates happen only after current-candle exit checks, so they
  become active on the following candle (no hidden intrabar path assumption).
- fees, adverse slippage, dynamic risk sizing, leverage cap and drawdown tracked.
"""
from __future__ import annotations

import argparse
import itertools
import json
import math
from dataclasses import asdict, dataclass, replace
from pathlib import Path
from typing import Literal

import numpy as np
import pandas as pd

Side = Literal["LONG", "SHORT"]
Mode = Literal["LONG", "SHORT", "BOTH"]
StrategyKind = Literal["V070_MTF", "DONCHIAN_SIMPLE", "EMA_TREND_SIMPLE"]


@dataclass(frozen=True)
class Params:
    strategy_kind: StrategyKind = "V070_MTF"
    ema_entry: int = 20
    ema_regime_fast: int = 80
    ema_regime_slow: int = 200
    donchian_period: int = 24
    swing_period: int = 12
    atr_period: int = 14
    adx_period: int = 14
    rsi_period: int = 14
    volume_period: int = 24
    risk_pct: float = 0.0015
    max_leverage: float = 1.0
    atr_stop_floor: float = 1.6
    atr_stop_cap: float = 3.0
    reward_risk: float = 2.6
    breakeven_r: float = 1.2
    trail_start_r: float = 1.8
    trail_atr_mult: float = 2.0
    adx_min: float = 22.0
    volume_mult: float = 1.10
    short_rsi_min: float = 32.0
    short_rsi_max: float = 48.0
    long_rsi_min: float = 52.0
    long_rsi_max: float = 68.0
    atr_pct_min: float = 0.004
    atr_pct_max: float = 0.030
    max_extension_atr: float = 2.2
    max_hold_bars: int = 10
    cooldown_bars: int = 8


@dataclass
class Trade:
    side: Side
    signal_time: str
    entry_time: str
    exit_time: str
    entry: float
    exit: float
    qty: float
    initial_risk: float
    risk_budget_per_unit: float
    stop_initial: float
    target_initial: float
    exit_reason: str
    bars_held: int
    gross_pnl: float
    fees: float
    net_pnl: float
    r_net: float
    equity_after: float


def load_ohlcv(path: Path) -> pd.DataFrame:
    if path.suffix == ".parquet":
        raw = pd.read_parquet(path)
    else:
        raw = pd.read_csv(path)
    lower = {str(c).lower(): c for c in raw.columns}
    time_col = next((lower[k] for k in ("open_time", "timestamp", "datetime", "date", "time") if k in lower), None)
    if time_col is None:
        raise ValueError("Timestamp/open_time column missing")
    rename = {time_col: "timestamp"}
    for name in ("open", "high", "low", "close", "volume"):
        if name not in lower:
            raise ValueError(f"{name} column missing")
        rename[lower[name]] = name
    x = raw.rename(columns=rename)[["timestamp", "open", "high", "low", "close", "volume"]].copy()
    if pd.api.types.is_numeric_dtype(x.timestamp):
        med = float(pd.to_numeric(x.timestamp, errors="coerce").dropna().median())
        x.timestamp = pd.to_datetime(x.timestamp, unit="ms" if med > 1e11 else "s", utc=True, errors="coerce")
    else:
        x.timestamp = pd.to_datetime(x.timestamp, utc=True, errors="coerce")
    for c in ("open", "high", "low", "close", "volume"):
        x[c] = pd.to_numeric(x[c], errors="coerce")
    x = x.dropna().sort_values("timestamp")
    if x.timestamp.duplicated().any():
        raise ValueError(f"Duplicate timestamps: {int(x.timestamp.duplicated().sum())}")
    x = x.set_index("timestamp")
    bad = (
        (x[["open", "high", "low", "close"]] <= 0).any(axis=1)
        | (x.volume < 0)
        | (x.high < x[["open", "close"]].max(axis=1))
        | (x.low > x[["open", "close"]].min(axis=1))
        | (x.high < x.low)
    )
    if bad.any():
        raise ValueError(f"Invalid OHLCV rows: {int(bad.sum())}")
    return x


def wilder(series: pd.Series, period: int) -> pd.Series:
    return series.ewm(alpha=1 / period, adjust=False, min_periods=period).mean()


def resample_4h(one_hour: pd.DataFrame) -> pd.DataFrame:
    return one_hour.resample("4h", label="left", closed="left", origin="epoch").agg(
        open=("open", "first"), high=("high", "max"), low=("low", "min"),
        close=("close", "last"), volume=("volume", "sum"),
    ).dropna()


def add_indicators(one_hour: pd.DataFrame, p: Params, four_hour: pd.DataFrame | None = None) -> pd.DataFrame:
    x = one_hour.copy().sort_index()
    x.index.name = "timestamp"
    x["ema_entry"] = x.close.ewm(span=p.ema_entry, adjust=False, min_periods=p.ema_entry).mean()
    previous_close = x.close.shift(1)
    tr = pd.concat([(x.high - x.low), (x.high - previous_close).abs(), (x.low - previous_close).abs()], axis=1).max(axis=1)
    x["atr"] = wilder(tr, p.atr_period)
    up = x.high.diff()
    down = -x.low.diff()
    plus_dm = pd.Series(np.where((up > down) & (up > 0), up, 0.0), index=x.index)
    minus_dm = pd.Series(np.where((down > up) & (down > 0), down, 0.0), index=x.index)
    plus_di = 100 * wilder(plus_dm, p.adx_period) / x.atr
    minus_di = 100 * wilder(minus_dm, p.adx_period) / x.atr
    dx = 100 * (plus_di - minus_di).abs() / (plus_di + minus_di).replace(0, np.nan)
    x["adx"] = wilder(dx, p.adx_period)
    delta = x.close.diff()
    avg_gain = wilder(delta.clip(lower=0), p.rsi_period)
    avg_loss = wilder((-delta).clip(lower=0), p.rsi_period)
    rs = avg_gain / avg_loss.replace(0, np.nan)
    rsi = 100 - 100 / (1 + rs)
    rsi = rsi.mask((avg_loss == 0) & (avg_gain > 0), 100.0)
    rsi = rsi.mask((avg_gain == 0) & (avg_loss > 0), 0.0)
    rsi = rsi.mask((avg_gain == 0) & (avg_loss == 0), 50.0)
    x["rsi"] = rsi
    x["volume_sma"] = x.volume.rolling(p.volume_period, min_periods=p.volume_period).mean()
    x["prior_low"] = x.low.shift(1).rolling(p.donchian_period, min_periods=p.donchian_period).min()
    x["prior_high"] = x.high.shift(1).rolling(p.donchian_period, min_periods=p.donchian_period).max()
    x["swing_high"] = x.high.shift(1).rolling(p.swing_period, min_periods=p.swing_period).max()
    x["swing_low"] = x.low.shift(1).rolling(p.swing_period, min_periods=p.swing_period).min()

    h4 = (four_hour.copy() if four_hour is not None else resample_4h(one_hour)).sort_index()
    h4.index.name = "timestamp"
    h4["regime_fast"] = h4.close.ewm(span=p.ema_regime_fast, adjust=False, min_periods=p.ema_regime_fast).mean()
    h4["regime_slow"] = h4.close.ewm(span=p.ema_regime_slow, adjust=False, min_periods=p.ema_regime_slow).mean()
    h4["regime_fast_prev"] = h4.regime_fast.shift(1)
    h4["regime_slow_prev3"] = h4.regime_slow.shift(3)
    # A 4h candle labelled T is usable only from T+4h onward.
    available = h4[["regime_fast", "regime_slow", "regime_fast_prev", "regime_slow_prev3"]].copy()
    available.index = available.index + pd.Timedelta(hours=4)
    signal_closes = pd.DataFrame({"signal_close_time": x.index + pd.Timedelta(hours=1)}, index=x.index)
    merged = pd.merge_asof(
        signal_closes.reset_index().sort_values("signal_close_time"),
        available.reset_index(names="regime_available_time").sort_values("regime_available_time"),
        left_on="signal_close_time", right_on="regime_available_time", direction="backward",
    ).set_index("timestamp")
    for c in ("regime_fast", "regime_slow", "regime_fast_prev", "regime_slow_prev3", "regime_available_time"):
        x[c] = merged[c].reindex(x.index)
    return x


def adverse_slip(price: float, side: Side, action: Literal["ENTRY", "EXIT"], rate: float) -> float:
    if side == "LONG":
        return price * (1 + rate) if action == "ENTRY" else price * (1 - rate)
    return price * (1 - rate) if action == "ENTRY" else price * (1 + rate)


def trigger_fill(side: Side, kind: Literal["STOP", "TARGET"], bar_open: float, level: float, slippage: float) -> float:
    # Stop gaps are filled at the worse open. Target gaps receive no positive improvement.
    if kind == "STOP":
        if side == "LONG":
            raw = min(bar_open, level)
        else:
            raw = max(bar_open, level)
    else:
        raw = level
    return adverse_slip(raw, side, "EXIT", slippage)


def signal_for(side: Side, row: pd.Series, p: Params) -> tuple[bool, float]:
    price = float(row.close)
    atr = max(float(row.atr), 1e-12)
    atr_pct = atr / price
    common = (
        float(row.volume) >= float(row.volume_sma) * p.volume_mult
        and float(row.adx) >= p.adx_min
        and p.atr_pct_min <= atr_pct <= p.atr_pct_max
    )
    if not common:
        return False, math.nan

    if side == "SHORT":
        regime = (
            float(row.regime_fast) < float(row.regime_slow)
            and float(row.regime_fast) < float(row.regime_fast_prev)
            and float(row.regime_slow) < float(row.regime_slow_prev3)
            and price < float(row.ema_entry)
        )
        momentum = p.short_rsi_min <= float(row.rsi) <= p.short_rsi_max
        breakout = price < float(row.prior_low)
        extension_ok = max(0.0, float(row.prior_low) - price) <= atr * p.max_extension_atr
        stop = max(float(row.swing_high), price + atr * p.atr_stop_floor)
        distance = stop - price
    else:
        regime = (
            float(row.regime_fast) > float(row.regime_slow)
            and float(row.regime_fast) > float(row.regime_fast_prev)
            and float(row.regime_slow) > float(row.regime_slow_prev3)
            and price > float(row.ema_entry)
        )
        momentum = p.long_rsi_min <= float(row.rsi) <= p.long_rsi_max
        breakout = price > float(row.prior_high)
        extension_ok = max(0.0, price - float(row.prior_high)) <= atr * p.max_extension_atr
        stop = min(float(row.swing_low), price - atr * p.atr_stop_floor)
        distance = price - stop

    if p.strategy_kind == "DONCHIAN_SIMPLE":
        regime = price < float(row.ema_entry) if side == "SHORT" else price > float(row.ema_entry)
        momentum = True
    elif p.strategy_kind == "EMA_TREND_SIMPLE":
        breakout = True
        extension_ok = True
        momentum = True

    stop_ok = atr * p.atr_stop_floor <= distance <= atr * p.atr_stop_cap
    return bool(regime and momentum and breakout and extension_ok and stop_ok), float(stop)


def _close_trade(position: dict, ts: pd.Timestamp, exit_price: float, reason: str, bar_index: int,
                 equity: float, fee_per_side: float) -> tuple[Trade, float]:
    qty = position["qty"]
    if position["side"] == "LONG":
        gross = (exit_price - position["entry"]) * qty
    else:
        gross = (position["entry"] - exit_price) * qty
    fees = fee_per_side * (position["entry"] + exit_price) * qty
    net = gross - fees
    equity += net
    risk_cash = position["risk_budget_per_unit"] * qty
    trade = Trade(
        side=position["side"], signal_time=str(position["signal_time"]),
        entry_time=str(position["entry_time"]), exit_time=str(ts),
        entry=position["entry"], exit=exit_price, qty=qty,
        initial_risk=position["initial_risk"], risk_budget_per_unit=position["risk_budget_per_unit"],
        stop_initial=position["stop_initial"],
        target_initial=position["target"], exit_reason=reason,
        bars_held=bar_index - position["entry_i"] + 1,
        gross_pnl=gross, fees=fees, net_pnl=net,
        r_net=net / risk_cash if risk_cash else 0.0, equity_after=equity,
    )
    return trade, equity


def run_backtest(one_hour: pd.DataFrame, p: Params = Params(), mode: Mode = "BOTH",
                 initial_cash: float = 100_000.0, fee_per_side: float = 0.0004,
                 slippage: float = 0.0001, four_hour: pd.DataFrame | None = None,
                 trade_start: str | pd.Timestamp | None = None,
                 trade_end: str | pd.Timestamp | None = None) -> tuple[pd.DataFrame, pd.DataFrame, dict]:
    x = add_indicators(one_hour, p, four_hour)
    required = ["ema_entry", "atr", "adx", "rsi", "volume_sma", "prior_low", "prior_high",
                "swing_high", "swing_low", "regime_fast", "regime_slow", "regime_fast_prev", "regime_slow_prev3"]
    equity = initial_cash
    realized_curve: list[tuple[pd.Timestamp, float]] = []
    trades: list[Trade] = []
    position: dict | None = None
    pending: dict | None = None
    scheduled_exit: str | None = None
    cooldown_until = -1
    allowed: tuple[Side, ...] = ("LONG", "SHORT") if mode == "BOTH" else (mode,)
    trade_start_ts = pd.Timestamp(trade_start) if trade_start is not None else None
    trade_end_ts = pd.Timestamp(trade_end) if trade_end is not None else None

    for i, (ts, row) in enumerate(x.iterrows()):
        if trade_end_ts is not None and ts >= trade_end_ts:
            break
        # Next-open exit has priority over a new entry.
        if position is not None and scheduled_exit is not None:
            px = adverse_slip(float(row.open), position["side"], "EXIT", slippage)
            trade, equity = _close_trade(position, ts, px, scheduled_exit, i, equity, fee_per_side)
            trades.append(trade)
            position = None
            scheduled_exit = None
            cooldown_until = i + p.cooldown_bars

        if position is None and pending is not None and i == pending["entry_i"]:
            side: Side = pending["side"]
            entry = adverse_slip(float(row.open), side, "ENTRY", slippage)
            distance = (entry - pending["structural_stop"]) if side == "LONG" else (pending["structural_stop"] - entry)
            if distance > 0 and distance <= pending["signal_atr"] * p.atr_stop_cap * 1.05:
                risk_cash = equity * p.risk_pct
                stop_exit_assumption = trigger_fill(
                    side, "STOP", pending["structural_stop"], pending["structural_stop"], slippage)
                gross_stop_loss_per_unit = (entry - stop_exit_assumption) if side == "LONG" else (stop_exit_assumption - entry)
                risk_budget_per_unit = gross_stop_loss_per_unit + fee_per_side * (entry + stop_exit_assumption)
                by_risk = risk_cash / max(risk_budget_per_unit, 1e-12)
                by_leverage = equity * p.max_leverage / max(entry, 1e-12)
                qty = max(0.0, min(by_risk, by_leverage))
                if qty > 0:
                    target = entry + distance * p.reward_risk if side == "LONG" else entry - distance * p.reward_risk
                    position = {
                        "side": side, "signal_time": pending["signal_time"], "entry_time": ts, "entry_i": i,
                        "entry": entry, "qty": qty, "initial_risk": distance,
                        "risk_budget_per_unit": risk_budget_per_unit,
                        "stop": pending["structural_stop"], "stop_initial": pending["structural_stop"],
                        "target": target, "best": entry,
                    }
            pending = None

        if position is not None:
            side = position["side"]
            stop = float(position["stop"])
            target = float(position["target"])
            if side == "LONG":
                stop_hit = float(row.low) <= stop
                target_hit = float(row.high) >= target
            else:
                stop_hit = float(row.high) >= stop
                target_hit = float(row.low) <= target
            # Existing stop is checked before target; no same-bar trailing lookahead.
            if stop_hit or target_hit:
                kind: Literal["STOP", "TARGET"] = "STOP" if stop_hit else "TARGET"
                level = stop if kind == "STOP" else target
                px = trigger_fill(side, kind, float(row.open), level, slippage)
                trade, equity = _close_trade(position, ts, px, kind, i, equity, fee_per_side)
                trades.append(trade)
                position = None
                cooldown_until = i + p.cooldown_bars
            else:
                # Stop adjustments become active only on next candle.
                if side == "LONG":
                    position["best"] = max(position["best"], float(row.high))
                    favorable = position["best"] - position["entry"]
                else:
                    position["best"] = min(position["best"], float(row.low))
                    favorable = position["entry"] - position["best"]
                r_multiple = favorable / max(position["initial_risk"], 1e-12)
                next_stop = stop
                if r_multiple >= p.breakeven_r:
                    next_stop = max(next_stop, position["entry"]) if side == "LONG" else min(next_stop, position["entry"])
                if r_multiple >= p.trail_start_r and not pd.isna(row.atr):
                    trail = position["best"] - float(row.atr) * p.trail_atr_mult if side == "LONG" else position["best"] + float(row.atr) * p.trail_atr_mult
                    next_stop = max(next_stop, trail) if side == "LONG" else min(next_stop, trail)
                position["stop"] = next_stop
                held = i - position["entry_i"] + 1
                if held >= p.max_hold_bars:
                    scheduled_exit = "MAX_HOLD"
                elif i >= 2 and not pd.isna(row.ema_entry):
                    ema_rising = float(row.ema_entry) > float(x.ema_entry.iloc[i - 2])
                    invalid = (side == "SHORT" and float(row.close) > float(row.ema_entry) and ema_rising) or (
                        side == "LONG" and float(row.close) < float(row.ema_entry) and not ema_rising
                    )
                    if invalid:
                        scheduled_exit = "TREND_INVALID"
            realized_curve.append((ts, equity))
            continue

        realized_curve.append((ts, equity))
        if trade_start_ts is not None and ts < trade_start_ts:
            continue
        if pending is not None or i < cooldown_until or row[required].isna().any():
            continue
        # At most one side may be scheduled. In BOTH mode, strongest regime distance wins.
        candidates: list[tuple[float, Side, float]] = []
        for side in allowed:
            ok, structural_stop = signal_for(side, row, p)
            if ok:
                regime_strength = abs(float(row.regime_fast) - float(row.regime_slow)) / max(float(row.close), 1e-12)
                candidates.append((regime_strength, side, structural_stop))
        if candidates and i + 1 < len(x):
            _, side, structural_stop = max(candidates, key=lambda z: z[0])
            pending = {
                "side": side, "signal_time": ts, "entry_i": i + 1,
                "structural_stop": structural_stop, "signal_atr": float(row.atr),
            }

    # Do not fabricate a final fill beyond available data. Open position is marked, not realized.
    trade_df = pd.DataFrame([asdict(t) for t in trades])
    curve = pd.DataFrame(realized_curve, columns=["timestamp", "realized_equity"]).drop_duplicates("timestamp", keep="last").set_index("timestamp")
    if len(curve):
        curve["peak"] = curve.realized_equity.cummax()
        curve["drawdown"] = curve.realized_equity / curve.peak - 1
    summary = summarize(trade_df, curve, initial_cash, equity, p, mode, fee_per_side, slippage, position)
    return trade_df, curve, summary


def summarize(trades: pd.DataFrame, curve: pd.DataFrame, initial_cash: float, ending_equity: float,
              p: Params, mode: Mode, fee: float, slippage: float, open_position: dict | None) -> dict:
    if len(trades):
        wins = trades.net_pnl > 0
        gross_win = float(trades.loc[wins, "net_pnl"].sum())
        gross_loss = float(-trades.loc[~wins, "net_pnl"].sum())
        long_count = int((trades.side == "LONG").sum())
        short_count = int((trades.side == "SHORT").sum())
        expectancy_r = float(trades.r_net.mean())
    else:
        wins = pd.Series(dtype=bool)
        gross_win = gross_loss = 0.0
        long_count = short_count = 0
        expectancy_r = 0.0
    daily = curve.realized_equity.resample("1D").last().ffill().pct_change().dropna() if len(curve) else pd.Series(dtype=float)
    sharpe = float(math.sqrt(365) * daily.mean() / daily.std(ddof=1)) if len(daily) > 2 and daily.std(ddof=1) > 0 else None
    max_dd = float(curve.drawdown.min() * 100) if len(curve) else 0.0
    return {
        "research_only": True,
        "mode": mode,
        "strategy_kind": p.strategy_kind,
        "initial_cash": initial_cash,
        "ending_realized_equity": ending_equity,
        "net_pnl": ending_equity - initial_cash,
        "return_pct": (ending_equity / initial_cash - 1) * 100,
        "trades": int(len(trades)),
        "long_trades": long_count,
        "short_trades": short_count,
        "win_rate_pct": float(100 * wins.mean()) if len(trades) else 0.0,
        "profit_factor": gross_win / gross_loss if gross_loss > 0 else None,
        "expectancy_r": expectancy_r,
        "max_drawdown_pct": max_dd,
        "daily_sharpe": sharpe,
        "fee_per_side": fee,
        "slippage": slippage,
        "open_position_unrealized": bool(open_position),
        "params": asdict(p),
    }


def split_frame(df: pd.DataFrame, start: str, end_exclusive: str) -> pd.DataFrame:
    return df[(df.index >= pd.Timestamp(start)) & (df.index < pd.Timestamp(end_exclusive))]


def neighbor_grid(base: Params, strategy_kind: StrategyKind) -> list[Params]:
    # Compact, predeclared neighbourhood: no OOS-driven parameter invention.
    values = {
        "reward_risk": [2.2, 2.6, 3.0],
        "adx_min": [20.0, 22.0, 24.0],
        "volume_mult": [1.0, 1.1, 1.2],
    }
    # 27 variants per strategy; all other parameters stay locked. This is broad
    # enough for neighbourhood stability while remaining reproducible and tractable.
    return [replace(base, strategy_kind=strategy_kind, **dict(zip(values, combo))) for combo in itertools.product(*values.values())]


def robustness_score(train: dict, validation: dict) -> float:
    if train["trades"] < 15 or validation["trades"] < 5:
        return -1e9
    pf_train = min(float(train["profit_factor"] or 0), 3.0)
    pf_val = min(float(validation["profit_factor"] or 0), 3.0)
    dd_penalty = abs(float(validation["max_drawdown_pct"])) / 10
    instability = abs(float(train["expectancy_r"]) - float(validation["expectancy_r"]))
    return min(pf_train, pf_val) + min(float(train["expectancy_r"]), float(validation["expectancy_r"])) - dd_penalty - instability


def run_research(corpus: pd.DataFrame, output: Path, base: Params = Params(), fee: float = 0.0004,
                 slippage: float = 0.0001) -> dict:
    output.mkdir(parents=True, exist_ok=True)
    boundaries = {
        "train": ("2024-07-17T00:00:00Z", "2025-12-01T00:00:00Z"),
        "validation": ("2025-12-01T00:00:00Z", "2026-03-01T00:00:00Z"),
        "final_oos": ("2026-03-01T00:00:00Z", "2026-07-17T00:00:00Z"),
    }
    # Validation/OOS receive indicator warm-up history, but entries are disabled
    # before each split boundary. The final OOS is never used for selection.
    train = split_frame(corpus, boundaries["train"][0], boundaries["train"][1])
    validation = split_frame(corpus, "2025-10-15T00:00:00Z", boundaries["validation"][1])
    oos = split_frame(corpus, "2026-01-15T00:00:00Z", boundaries["final_oos"][1])
    rows: list[dict] = []
    candidates: list[tuple[float, Params, Mode, dict, dict]] = []
    for kind in ("V070_MTF", "DONCHIAN_SIMPLE", "EMA_TREND_SIMPLE"):
        for p in neighbor_grid(base, kind):
            for mode in ("LONG", "SHORT", "BOTH"):
                _, _, train_summary = run_backtest(
                    train, p, mode, fee_per_side=fee, slippage=slippage,
                    trade_start=boundaries["train"][0], trade_end=boundaries["train"][1])
                _, _, val_summary = run_backtest(
                    validation, p, mode, fee_per_side=fee, slippage=slippage,
                    trade_start=boundaries["validation"][0], trade_end=boundaries["validation"][1])
                score = robustness_score(train_summary, val_summary)
                row = {
                    "strategy_kind": kind, "mode": mode, "score": score,
                    "reward_risk": p.reward_risk, "adx_min": p.adx_min,
                    "volume_mult": p.volume_mult, "atr_stop_floor": p.atr_stop_floor,
                    "train_trades": train_summary["trades"], "train_return_pct": train_summary["return_pct"],
                    "train_pf": train_summary["profit_factor"], "train_dd_pct": train_summary["max_drawdown_pct"],
                    "train_expectancy_r": train_summary["expectancy_r"],
                    "validation_trades": val_summary["trades"], "validation_return_pct": val_summary["return_pct"],
                    "validation_pf": val_summary["profit_factor"], "validation_dd_pct": val_summary["max_drawdown_pct"],
                    "validation_expectancy_r": val_summary["expectancy_r"],
                }
                rows.append(row)
                candidates.append((score, p, mode, train_summary, val_summary))
    grid = pd.DataFrame(rows).sort_values("score", ascending=False)
    grid.to_csv(output / "parameter_neighbourhood_train_validation.csv", index=False)
    best_score, best_params, best_mode, train_summary, val_summary = max(candidates, key=lambda item: item[0])
    locked_neighbours = grid[(grid.strategy_kind == best_params.strategy_kind) & (grid["mode"] == best_mode)]
    neighbour_support = int((
        (locked_neighbours.validation_trades >= 5)
        & (pd.to_numeric(locked_neighbours.validation_pf, errors="coerce").fillna(0.0) > 1.0)
        & (locked_neighbours.validation_expectancy_r > 0)
    ).sum())
    # Re-run the locked candidate for auditable train/validation trade files.
    train_trades, train_curve, train_summary = run_backtest(
        train, best_params, best_mode, fee_per_side=fee, slippage=slippage,
        trade_start=boundaries["train"][0], trade_end=boundaries["train"][1])
    val_trades, val_curve, val_summary = run_backtest(
        validation, best_params, best_mode, fee_per_side=fee, slippage=slippage,
        trade_start=boundaries["validation"][0], trade_end=boundaries["validation"][1])
    train_trades.to_csv(output / "locked_train_trades.csv", index=False)
    train_curve.to_csv(output / "locked_train_equity.csv")
    val_trades.to_csv(output / "locked_validation_trades.csv", index=False)
    val_curve.to_csv(output / "locked_validation_equity.csv")

    # Execution-cost stress is validation-only, preserving the final OOS untouched.
    validation_stress = {}
    for label, stress_fee, stress_slip in (
        ("base", fee, slippage),
        ("fees_x1_5", fee * 1.5, slippage),
        ("slippage_x2", fee, slippage * 2.0),
        ("fees_x1_5_slippage_x2", fee * 1.5, slippage * 2.0),
    ):
        _, _, stress_summary = run_backtest(
            validation, best_params, best_mode, fee_per_side=stress_fee, slippage=stress_slip,
            trade_start=boundaries["validation"][0], trade_end=boundaries["validation"][1])
        validation_stress[label] = stress_summary

    validation_stress_pass = all(
        (item["profit_factor"] or 0) > 1.0 and item["expectancy_r"] > 0
        for item in validation_stress.values()
    )
    validation_candidate_locked = bool(
        best_score > -1e8
        and (val_summary["profit_factor"] or 0) > 1.0
        and val_summary["expectancy_r"] > 0
        and val_summary["trades"] >= 5
        and neighbour_support >= 3
        and validation_stress_pass
    )

    # The final OOS stays completely unopened unless train/validation have produced
    # a lockable candidate. When lockable, it is evaluated exactly once.
    if validation_candidate_locked:
        oos_trades, oos_curve, oos_summary = run_backtest(
            oos, best_params, best_mode, fee_per_side=fee, slippage=slippage,
            trade_start=boundaries["final_oos"][0], trade_end=boundaries["final_oos"][1])
        oos_evaluated = True
    else:
        oos_trades = pd.DataFrame()
        oos_curve = pd.DataFrame()
        oos_summary = {
            "status": "NOT_EVALUATED_NO_VALIDATION_CANDIDATE",
            "research_only": True,
            "reason": "Final OOS preserved because train/validation lock criteria were not met.",
        }
        oos_evaluated = False
    oos_trades.to_csv(output / "final_oos_trades.csv", index=False)
    oos_curve.to_csv(output / "final_oos_equity.csv")
    report = {
        "research_only": True,
        "selection_score": best_score,
        "neighbour_support_positive_validation": neighbour_support,
        "locked_mode": best_mode,
        "locked_params": asdict(best_params),
        "boundaries": boundaries,
        "train": train_summary,
        "validation": val_summary,
        "validation_execution_cost_stress": validation_stress,
        "validation_execution_cost_stress_pass": validation_stress_pass,
        "validation_candidate_locked": validation_candidate_locked,
        "final_oos_evaluated": oos_evaluated,
        "final_oos": oos_summary,
        "oos_access_policy": "Final OOS is not opened without a validation lock; otherwise evaluated exactly once.",
        "stable": bool(
            validation_candidate_locked
            and oos_evaluated
            and (oos_summary.get("profit_factor") or 0) > 1.0
            and oos_summary.get("expectancy_r", 0) > 0
            and oos_summary.get("trades", 0) >= 10
            and oos_summary.get("max_drawdown_pct", -100.0) > -15.0
        ),
        "android_integration_allowed": False,
    }
    (output / "RESEARCH_REPORT.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    return report


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("corpus", type=Path)
    parser.add_argument("--output", type=Path, default=Path("v233_research_results"))
    parser.add_argument("--fee", type=float, default=0.0004)
    parser.add_argument("--slippage", type=float, default=0.0001)
    args = parser.parse_args()
    data = load_ohlcv(args.corpus)
    report = run_research(data, args.output, fee=args.fee, slippage=args.slippage)
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
