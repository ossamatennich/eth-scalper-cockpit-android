import backtrader as bt


class ETHIntraday4HRegime1HShort(bt.Strategy):
    params = (
        ('ema_entry', 20),
        ('ema_regime_fast', 80),
        ('ema_regime_slow', 200),
        ('donchian_period', 24),
        ('swing_period', 12),
        ('atr_period', 14),
        ('adx_period', 14),
        ('rsi_period', 14),
        ('volume_period', 24),
        ('risk_pct', 0.0015),
        ('atr_stop_floor', 1.6),
        ('atr_stop_cap', 3.0),
        ('reward_risk', 2.6),
        ('breakeven_r', 1.2),
        ('trail_start_r', 1.8),
        ('trail_atr_mult', 2.0),
        ('adx_min', 22.0),
        ('volume_mult', 1.10),
        ('rsi_min', 32.0),
        ('rsi_max', 48.0),
        ('atr_pct_min', 0.004),
        ('atr_pct_max', 0.030),
        ('max_extension_atr', 2.2),
        ('max_hold_bars', 10),
        ('cooldown_bars', 8),
    )

    def __init__(self):
        self.ema_entry_i = bt.indicators.EMA(self.data.close, period=self.p.ema_entry)
        self.ema_fast_i = bt.indicators.EMA(self.data.close, period=self.p.ema_regime_fast)
        self.ema_slow_i = bt.indicators.EMA(self.data.close, period=self.p.ema_regime_slow)
        self.atr = bt.indicators.ATR(self.data, period=self.p.atr_period)
        self.adx = bt.indicators.ADX(self.data, period=self.p.adx_period)
        self.rsi = bt.indicators.RSI(self.data.close, period=self.p.rsi_period)
        self.vol_sma = bt.indicators.SMA(self.data.volume, period=self.p.volume_period)
        self.prior_low = bt.indicators.Lowest(self.data.low(-1), period=self.p.donchian_period)
        self.swing_high = bt.indicators.Highest(self.data.high(-1), period=self.p.swing_period)

        self.order = None
        self.entry_price = None
        self.entry_bar = None
        self.initial_risk = None
        self.stop_price = None
        self.target_price = None
        self.low_since = None
        self.pending_risk = None
        self.cooldown_until = 0

    def _reset(self):
        self.entry_price = None
        self.entry_bar = None
        self.initial_risk = None
        self.stop_price = None
        self.target_price = None
        self.low_since = None
        self.pending_risk = None

    def notify_order(self, order):
        if order.status in [order.Submitted, order.Accepted]:
            return

        if order.status == order.Completed:
            if self.position.size < 0 and order.issell():
                self.entry_price = float(order.executed.price)
                self.entry_bar = len(self)
                self.initial_risk = max(float(self.pending_risk or 0.0), 0.01)
                self.stop_price = self.entry_price + self.initial_risk
                self.target_price = self.entry_price - self.initial_risk * self.p.reward_risk
                self.low_since = self.entry_price
            elif not self.position:
                self._reset()
                self.cooldown_until = len(self) + self.p.cooldown_bars
        elif order.status in [order.Canceled, order.Margin, order.Rejected]:
            self.pending_risk = None

        self.order = None

    def _risk_size(self, distance):
        if distance <= 0:
            return 0.0
        equity = max(float(self.broker.getvalue()), 0.0)
        risk_cash = equity * self.p.risk_pct
        by_risk = risk_cash / distance
        by_cash = equity * 0.90 / max(float(self.data.close[0]), 0.01)
        return max(0.0, min(by_risk, by_cash))

    def _manage_short(self):
        price = float(self.data.close[0])
        atr = max(float(self.atr[0]), 0.01)
        held = len(self) - int(self.entry_bar or len(self))
        self.low_since = min(float(self.low_since), float(self.data.low[0]))

        favorable = self.entry_price - self.low_since
        r_multiple = favorable / max(float(self.initial_risk), 0.01)

        if r_multiple >= self.p.breakeven_r:
            self.stop_price = min(float(self.stop_price), float(self.entry_price))

        if r_multiple >= self.p.trail_start_r:
            trail = self.low_since + atr * self.p.trail_atr_mult
            self.stop_price = min(float(self.stop_price), float(trail))

        if self.data.high[0] >= self.stop_price:
            self.order = self.close()
            return
        if self.data.low[0] <= self.target_price:
            self.order = self.close()
            return
        if held >= self.p.max_hold_bars:
            self.order = self.close()
            return

        trend_invalid = (
            price > self.ema_entry_i[0]
            and self.ema_entry_i[0] > self.ema_entry_i[-2]
        )
        if trend_invalid:
            self.order = self.close()

    def next(self):
        warmup = self.p.ema_regime_slow + self.p.donchian_period + 10
        if len(self) < warmup:
            return

        if self.position:
            if not self.order:
                self._manage_short()
            return

        if self.order or len(self) < self.cooldown_until:
            return

        price = float(self.data.close[0])
        atr = max(float(self.atr[0]), 0.01)
        atr_pct = atr / max(price, 0.01)

        regime_short = (
            self.ema_fast_i[0] < self.ema_slow_i[0]
            and self.ema_fast_i[0] < self.ema_fast_i[-4]
            and self.ema_slow_i[0] < self.ema_slow_i[-12]
            and price < self.ema_entry_i[0]
        )

        vol_ok = (
            self.vol_sma[0] > 0
            and self.data.volume[0] >= self.vol_sma[0] * self.p.volume_mult
        )
        volatility_ok = self.p.atr_pct_min <= atr_pct <= self.p.atr_pct_max
        momentum_ok = self.p.rsi_min <= self.rsi[0] <= self.p.rsi_max
        adx_ok = self.adx[0] >= self.p.adx_min

        breakout_level = float(self.prior_low[0])
        breakdown = price < breakout_level
        extension = max(0.0, breakout_level - price)
        extension_ok = extension <= atr * self.p.max_extension_atr

        structural_stop = max(float(self.swing_high[0]), price + atr * self.p.atr_stop_floor)
        distance = structural_stop - price
        stop_ok = (
            distance >= atr * self.p.atr_stop_floor
            and distance <= atr * self.p.atr_stop_cap
        )

        if regime_short and vol_ok and volatility_ok and momentum_ok and adx_ok and breakdown and extension_ok and stop_ok:
            size = self._risk_size(distance)
            if size > 0:
                self.pending_risk = distance
                self.order = self.sell(size=size)
