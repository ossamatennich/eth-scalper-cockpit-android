import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
from v233_intraday_backtester import _slip,_trigger_fill,audit_data
import pandas as pd

def test_adverse_slippage():
    assert _slip(100,'SHORT','ENTRY',.01)==99
    assert _slip(100,'SHORT','EXIT',.01)==101
    assert _slip(100,'LONG','ENTRY',.01)==101
    assert _slip(100,'LONG','EXIT',.01)==99

def test_gap_fills():
    assert _trigger_fill('SHORT','STOP',110,105,0)==110
    assert _trigger_fill('SHORT','TARGET',90,95,0)==90
    assert _trigger_fill('LONG','STOP',90,95,0)==90
    assert _trigger_fill('LONG','TARGET',110,105,0)==110

def test_audit_gap():
    idx=pd.to_datetime(['2026-01-01 00:00Z','2026-01-01 01:00Z','2026-01-01 03:00Z'])
    df=pd.DataFrame({'open':[1]*3,'high':[1]*3,'low':[1]*3,'close':[1]*3,'volume':[1]*3},index=idx)
    a=audit_data(df); assert a['gaps']==1 and a['timezone']=='UTC'
