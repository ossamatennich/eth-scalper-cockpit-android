from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f"{label}: expected exactly one match, found {count}")
    return text.replace(old, new, 1)


def patch_file(path: Path, transform):
    original = path.read_text(encoding="utf-8")
    updated = transform(original)
    if updated == original:
        raise RuntimeError(f"No change produced for {path}")
    path.write_text(updated, encoding="utf-8")


def patch_market_watch(text: str) -> str:
    text = replace_once(
        text,
        "    private static final long LIMIT_MANUAL_ENTRY_DELAY_MS = 15 * 1000L;\n",
        "    private static final long LIMIT_MANUAL_ENTRY_DELAY_MS = 15 * 1000L;\n"
        "    private static final long ETH_BOOK_MAX_AGE_MS = 8_000L;\n"
        "    private static final long ETH_KLINE_MAX_AGE_MS = 12_000L;\n",
        "feed constants",
    )

    text = replace_once(
        text,
        "    private long lastBookTickerAt;\n    private long lastKlineAt;\n",
        "    private long lastBookTickerAt;\n"
        "    private long lastEthBookTickerAt;\n"
        "    private long lastEthKlineAt;\n"
        "    private long lastKlineAt;\n",
        "per-symbol feed clocks",
    )

    old_book = '''    private void handleBookTicker(String stream, JSONObject data) {
        bookTickerMessages++;
        lastBookTickerAt = System.currentTimeMillis();
        if (stream.startsWith("ethusdt")) {
            ethBid = data.optDouble("b", ethBid);
            ethAsk = data.optDouble("a", ethAsk);
            if (ethBid > 0 && ethAsk > 0) ethLast = (ethBid + ethAsk) / 2.0;
        } else if (stream.startsWith("btcusdt")) {
            btcBid = data.optDouble("b", btcBid);
            btcAsk = data.optDouble("a", btcAsk);
            if (btcBid > 0 && btcAsk > 0) btcLast = (btcBid + btcAsk) / 2.0;
        }
    }
'''
    new_book = '''    private void handleBookTicker(String stream, JSONObject data) {
        bookTickerMessages++;
        long now = System.currentTimeMillis();
        lastBookTickerAt = now;
        if (stream.startsWith("ethusdt")) {
            lastEthBookTickerAt = now;
            ethBid = data.optDouble("b", ethBid);
            ethAsk = data.optDouble("a", ethAsk);
            if (ethBid > 0 && ethAsk > 0) ethLast = (ethBid + ethAsk) / 2.0;
        } else if (stream.startsWith("btcusdt")) {
            btcBid = data.optDouble("b", btcBid);
            btcAsk = data.optDouble("a", btcAsk);
            if (btcBid > 0 && btcAsk > 0) btcLast = (btcBid + btcAsk) / 2.0;
        }
    }
'''
    text = replace_once(text, old_book, new_book, "ETH book clock")

    old_kline = '''        if (stream.startsWith("ethusdt")) {
            ethLast = candle.close;
            upsert(ethCandles, candle, 180);
        } else if (stream.startsWith("btcusdt")) {
'''
    new_kline = '''        if (stream.startsWith("ethusdt")) {
            lastEthKlineAt = System.currentTimeMillis();
            ethLast = candle.close;
            upsert(ethCandles, candle, 180);
        } else if (stream.startsWith("btcusdt")) {
'''
    text = replace_once(text, old_kline, new_kline, "ETH kline clock")

    old_eval = '''    private synchronized void evaluateSignal(long now) {
        MarketSnapshot snapshot = buildSnapshot(now);
        updateObservedSignals(snapshot, now);

        SignalDecision rawDecision = signalEngine.evaluate(snapshot);
'''
    new_eval = '''    private synchronized void evaluateSignal(long now) {
        MarketSnapshot snapshot = buildSnapshot(now);

        // v2.32.6 safety separation: always manage existing risk first.
        updateObservedSignals(snapshot, now);

        if (!ethExecutionFeedFresh(now)) {
            SignalDecision staleFeed = SignalDecision.waiting(
                    "V2326_ETH_FEED_STALE",
                    "Nouvelle entrée bloquée : prix ETH temps réel trop ancien",
                    0, "", false, 0, 0, 0, false);
            recordMarketFrame(snapshot, staleFeed, now);
            lastDecision = staleFeed;
            broadcastStatus(
                    "eth_feed_stale_new_entries_blocked",
                    "Flux ETH périmé : nouvelles entrées bloquées, surveillance TP/SL active maintenue");
            return;
        }

        SignalDecision rawDecision = signalEngine.evaluate(snapshot);
'''
    text = replace_once(text, old_eval, new_eval, "evaluation feed guard")

    insert_before = '''    private SignalDecision applyAiGate(MarketSnapshot snapshot, SignalDecision decision, long now) {
'''
    helper = '''    private boolean ethExecutionFeedFresh(long now) {
        if (ethBid <= 0 || ethAsk <= 0 || ethLast <= 0) return false;
        long bookAge = lastEthBookTickerAt <= 0 ? Long.MAX_VALUE : now - lastEthBookTickerAt;
        long klineAge = lastEthKlineAt <= 0 ? Long.MAX_VALUE : now - lastEthKlineAt;
        return bookAge <= ETH_BOOK_MAX_AGE_MS && klineAge <= ETH_KLINE_MAX_AGE_MS;
    }

'''
    text = replace_once(text, insert_before, helper + insert_before, "feed helper")

    old_cont = '''        // Replay v2.32.2/v2.32.5 :
        // les continuations prises en plein burst donnaient souvent un SL rapide.
        if (move1 > avg * 1.15 && s.volumeRatio > 1.50) return true;
'''
    new_cont = '''        // Walk-forward v2.32.6 : exiger une impulsion fraîche, une tendance 8m alignée
        // et un volume minimal. Les seuils voisins ont été testés séparément.
        if (move1 < avg * 0.50) return true;
        if (move8 < avg * 1.20) return true;
        if (s.volumeRatio < 0.35) return true;

        // Les continuations prises en plein burst donnaient souvent un SL rapide.
        if (move1 > avg * 1.15 && s.volumeRatio > 1.50) return true;
'''
    text = replace_once(text, old_cont, new_cont, "continuation quality floor")

    old_fade = '''        // Exiger un rejet immédiat du prix ou du flow.
        boolean immediateRejection =
                move1 > avg * 0.20
                || flow30 > 0.05
                || flow60 > 0.50;

        return !immediateRejection;
'''
    new_fade = '''        // Walk-forward v2.32.6 : le flow seul ne suffit pas.
        // Un RANGE_FADE doit montrer un vrai rejet du prix dans le sens du trade.
        boolean immediatePriceRejection = move1 >= avg * 0.50;

        return !immediatePriceRejection;
'''
    text = replace_once(text, old_fade, new_fade, "range fade price rejection")

    old_adverse = '''        // La LIMIT a été traversée trop loin : le contexte d'entrée n'est plus celui du signal.
        if (adverse >= Math.min(0.30, stop * 0.24)) {
            return "PRIX_DEJA_TROP_LOIN";
        }
'''
    new_adverse = '''        double pendingFavorable = pendingFavorableExcursion(item);
        if (pendingFavorable >= item.signal.targetMove * 0.75) {
            return "RETOUR_APRES_MOUVEMENT_CONSOMME";
        }

        // La LIMIT a été traversée trop loin : le contexte d'entrée n'est plus celui du signal.
        // Seuil légèrement relevé afin de ne pas supprimer les retours encore valides.
        if (adverse >= Math.min(0.45, stop * 0.34)) {
            return "PRIX_DEJA_TROP_LOIN";
        }
'''
    text = replace_once(text, old_adverse, new_adverse, "pending excursion veto")

    trigger_marker = '''    private String entryTriggerRevalidationCode(ObservedSignal item, MarketSnapshot s, double price) {
'''
    trigger_helper = '''    private static double pendingFavorableExcursion(ObservedSignal item) {
        if (item == null || item.signal == null) return 0.0;
        if ("LONG".equals(item.signal.side)) return Math.max(0, item.maxPrice - item.signal.entry);
        if ("SHORT".equals(item.signal.side)) return Math.max(0, item.signal.entry - item.minPrice);
        return 0.0;
    }

'''
    text = replace_once(text, trigger_marker, trigger_helper + trigger_marker, "pending excursion helper")

    text = text.replace('pendingStatus = "MISSED_NO_FILL";', 'pendingStatus = "MISSED_FAST_DEPARTURE";')
    text = text.replace('"MISSED_NO_FILL".equals(status)', '"MISSED_FAST_DEPARTURE".equals(status)')
    text = text.replace('else if ("MISSED_NO_FILL".equals(item.status)) missedNoFill++;',
                        'else if ("MISSED_FAST_DEPARTURE".equals(item.status)) missedNoFill++;')

    text = text.replace("2.32.5", "2.32.6")
    text = text.replace("v2.32.5", "v2.32.6")
    return text


def patch_main_activity(text: str) -> str:
    return text.replace("2.32.5", "2.32.6").replace("v2.32.5", "v2.32.6")


def patch_build_gradle(text: str) -> str:
    text = replace_once(text, "versionCode 23250", "versionCode 23260", "versionCode")
    return replace_once(text, "versionName '2.32.5'", "versionName '2.32.6'", "versionName")


patch_file(ROOT / "app/build.gradle", patch_build_gradle)
patch_file(ROOT / "app/src/main/java/com/ethscalper/cockpit/MainActivity.java", patch_main_activity)
patch_file(ROOT / "app/src/main/java/com/ethscalper/cockpit/MarketWatchService.java", patch_market_watch)

for optional in [
    ROOT / "app/src/main/java/com/ethscalper/cockpit/MarketSnapshot.java",
    ROOT / "app/src/main/java/com/ethscalper/cockpit/SignalEngine.java",
]:
    if optional.exists():
        value = optional.read_text(encoding="utf-8").replace("2.32.5", "2.32.6").replace("v2.32.5", "v2.32.6")
        optional.write_text(value, encoding="utf-8")

print("v2.32.6 candidate patch applied")
