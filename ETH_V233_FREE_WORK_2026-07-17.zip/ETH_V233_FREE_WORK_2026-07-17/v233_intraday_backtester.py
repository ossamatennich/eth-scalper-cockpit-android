#!/usr/bin/env python3
"""Deterministic research-only event backtester for ETH Scalper Cockpit v2.33.

Implements the v0.7.0 short logic without Backtrader fill ambiguity.
- signal computed from fully closed 1h bar
- market entry at next bar open
- adverse slippage on entries/exits
- fee per side
- SL-first when SL and TP are both touched in one bar
- stop/target fills at explicit trigger price with gap handling
- risk sizing from current realized equity
- optional true 4h regime source (disabled for exact-v0.7 mode)
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Literal, Optional
import argparse, json, math
import numpy as np
import pandas as pd

Side = Literal['LONG','SHORT']

@dataclass(frozen=True)
class Params:
    ema_entry:int=20; ema_regime_fast:int=80; ema_regime_slow:int=200
    donchian_period:int=24; swing_period:int=12; atr_period:int=14
    adx_period:int=14; rsi_period:int=14; volume_period:int=24
    risk_pct:float=.0015; atr_stop_floor:float=1.6; atr_stop_cap:float=3.0
    reward_risk:float=2.6; breakeven_r:float=1.2; trail_start_r:float=1.8
    trail_atr_mult:float=2.0; adx_min:float=22.; volume_mult:float=1.10
    rsi_min:float=32.; rsi_max:float=48.; atr_pct_min:float=.004
    atr_pct_max:float=.030; max_extension_atr:float=2.2
    max_hold_bars:int=10; cooldown_bars:int=8

@dataclass
class Trade:
    side:Side; signal_time:str; entry_time:str; exit_time:str
    entry:float; exit:float; qty:float; initial_risk:float
    stop_initial:float; target_initial:float; reason:str; bars:int
    gross_pnl:float; fees:float; net_pnl:float; r_net:float
    equity_after:float


def load_ohlcv(path:Path)->pd.DataFrame:
    df=pd.read_csv(path)
    lower={c.lower():c for c in df.columns}
    t=next((lower[x] for x in ('timestamp','datetime','date','time','open_time') if x in lower),None)
    if t is None: raise ValueError('timestamp column missing')
    ren={t:'timestamp'}
    for x in ('open','high','low','close','volume'):
        if x not in lower: raise ValueError(f'{x} column missing')
        ren[lower[x]]=x
    df=df.rename(columns=ren)[['timestamp','open','high','low','close','volume']].copy()
    if pd.api.types.is_numeric_dtype(df['timestamp']):
        med=float(pd.to_numeric(df['timestamp'],errors='coerce').dropna().median())
        unit='ms' if med>1e11 else 's'
        df['timestamp']=pd.to_datetime(df['timestamp'],unit=unit,utc=True,errors='coerce')
    else:
        df['timestamp']=pd.to_datetime(df['timestamp'],utc=True,errors='coerce')
    for c in ('open','high','low','close','volume'): df[c]=pd.to_numeric(df[c],errors='coerce')
    df=df.dropna().sort_values('timestamp').drop_duplicates('timestamp',keep='last').set_index('timestamp')
    bad=(df[['open','high','low','close']]<=0).any(axis=1)|(df['volume']<0)|(df['high']<df[['open','close']].max(axis=1))|(df['low']>df[['open','close']].min(axis=1))
    if bad.any(): raise ValueError(f'invalid OHLCV rows: {int(bad.sum())}')
    return df


def wilder(s:pd.Series,n:int)->pd.Series: return s.ewm(alpha=1/n,adjust=False,min_periods=n).mean()

def indicators(df:pd.DataFrame,p:Params)->pd.DataFrame:
    x=df.copy()
    x['ema_entry']=x.close.ewm(span=p.ema_entry,adjust=False,min_periods=p.ema_entry).mean()
    x['ema_fast']=x.close.ewm(span=p.ema_regime_fast,adjust=False,min_periods=p.ema_regime_fast).mean()
    x['ema_slow']=x.close.ewm(span=p.ema_regime_slow,adjust=False,min_periods=p.ema_regime_slow).mean()
    pc=x.close.shift(1)
    tr=pd.concat([(x.high-x.low),(x.high-pc).abs(),(x.low-pc).abs()],axis=1).max(axis=1)
    x['atr']=wilder(tr,p.atr_period)
    up=x.high.diff(); dn=-x.low.diff()
    plus=np.where((up>dn)&(up>0),up,0.0); minus=np.where((dn>up)&(dn>0),dn,0.0)
    plus_di=100*wilder(pd.Series(plus,index=x.index),p.adx_period)/x.atr
    minus_di=100*wilder(pd.Series(minus,index=x.index),p.adx_period)/x.atr
    dx=100*(plus_di-minus_di).abs()/(plus_di+minus_di).replace(0,np.nan)
    x['adx']=wilder(dx,p.adx_period)
    delta=x.close.diff(); gain=delta.clip(lower=0); loss=(-delta).clip(lower=0)
    rs=wilder(gain,p.rsi_period)/wilder(loss,p.rsi_period).replace(0,np.nan)
    x['rsi']=100-(100/(1+rs))
    x['vol_sma']=x.volume.rolling(p.volume_period,min_periods=p.volume_period).mean()
    x['prior_low']=x.low.shift(1).rolling(p.donchian_period,min_periods=p.donchian_period).min()
    x['swing_high']=x.high.shift(1).rolling(p.swing_period,min_periods=p.swing_period).max()
    return x


def _slip(price:float,side:Side,action:Literal['ENTRY','EXIT'],rate:float)->float:
    # Adverse in all cases. SHORT entry sells lower; SHORT exit buys higher.
    if side=='SHORT': return price*(1-rate) if action=='ENTRY' else price*(1+rate)
    return price*(1+rate) if action=='ENTRY' else price*(1-rate)


def _trigger_fill(side:Side,kind:Literal['STOP','TARGET'],o:float,level:float,slip:float)->float:
    if side=='SHORT':
        raw=max(o,level) if kind=='STOP' else min(o,level)
    else:
        raw=min(o,level) if kind=='STOP' else max(o,level)
    return _slip(raw,side,'EXIT',slip)


def backtest_short(df:pd.DataFrame,p:Params=Params(),initial_cash:float=100000.,fee:float=.0004,slippage:float=.0001)->tuple[pd.DataFrame,dict]:
    x=indicators(df,p)
    eq=initial_cash; trades:list[Trade]=[]; pos=None; pending=None; market_exit=None; cooldown_until=-1
    warm=p.ema_regime_slow+p.donchian_period+10
    for i,(ts,r) in enumerate(x.iterrows()):
        # Scheduled fills happen at current open, before evaluating the current closed bar.
        if market_exit is not None and pos is not None:
            px=_slip(float(r.open),'SHORT','EXIT',slippage); qty=pos['qty']
            gross=(pos['entry']-px)*qty; fees=fee*(pos['entry']+px)*qty; net=gross-fees; eq+=net
            risk_cash=pos['initial_risk']*qty
            trades.append(Trade('SHORT',str(pos['signal_time']),str(pos['entry_time']),str(ts),pos['entry'],px,qty,pos['initial_risk'],pos['stop_initial'],pos['target'],market_exit,i-pos['entry_i'],gross,fees,net,net/risk_cash if risk_cash else 0,eq))
            pos=None; market_exit=None; cooldown_until=i+p.cooldown_bars
        if pending is not None and pos is None:
            entry=_slip(float(r.open),'SHORT','ENTRY',slippage)
            # Recompute distance from actual fill to the signal-bar structural stop.
            distance=pending['structural_stop']-entry
            if distance>0 and distance<=pending['atr']*p.atr_stop_cap*1.05:
                risk_cash=eq*p.risk_pct; qty=min(risk_cash/distance,eq*.90/max(entry,.01))
                if qty>0:
                    pos={'signal_time':pending['signal_time'],'entry_time':ts,'entry_i':i,'entry':entry,'qty':qty,'initial_risk':distance,'stop':entry+distance,'stop_initial':entry+distance,'target':entry-distance*p.reward_risk,'low_since':entry}
            pending=None
        if pos is not None:
            pos['low_since']=min(pos['low_since'],float(r.low))
            fav=pos['entry']-pos['low_since']; rm=fav/max(pos['initial_risk'],.01)
            if rm>=p.breakeven_r: pos['stop']=min(pos['stop'],pos['entry'])
            if rm>=p.trail_start_r: pos['stop']=min(pos['stop'],pos['low_since']+float(r.atr)*p.trail_atr_mult)
            stop_hit=float(r.high)>=pos['stop']; target_hit=float(r.low)<=pos['target']
            # Conservative same-bar rule: stop first.
            if stop_hit or target_hit:
                kind='STOP' if stop_hit else 'TARGET'; level=pos['stop'] if stop_hit else pos['target']
                px=_trigger_fill('SHORT',kind,float(r.open),level,slippage); qty=pos['qty']
                gross=(pos['entry']-px)*qty; fees=fee*(pos['entry']+px)*qty; net=gross-fees; eq+=net
                risk_cash=pos['initial_risk']*qty
                trades.append(Trade('SHORT',str(pos['signal_time']),str(pos['entry_time']),str(ts),pos['entry'],px,qty,pos['initial_risk'],pos['stop_initial'],pos['target'],kind,i-pos['entry_i']+1,gross,fees,net,net/risk_cash if risk_cash else 0,eq))
                pos=None; cooldown_until=i+p.cooldown_bars
            elif i-pos['entry_i']>=p.max_hold_bars:
                market_exit='MAX_HOLD'
            elif float(r.close)>float(r.ema_entry) and float(r.ema_entry)>float(x.ema_entry.iloc[i-2] if i>=2 else r.ema_entry):
                market_exit='TREND_INVALID'
            continue
        if i<warm or i<cooldown_until or pending is not None: continue
        vals=[r.ema_entry,r.ema_fast,r.ema_slow,r.atr,r.adx,r.rsi,r.vol_sma,r.prior_low,r.swing_high]
        if any(pd.isna(v) for v in vals): continue
        price=float(r.close); atr=max(float(r.atr),.01); atr_pct=atr/max(price,.01)
        regime=float(r.ema_fast)<float(r.ema_slow) and float(r.ema_fast)<float(x.ema_fast.iloc[i-4]) and float(r.ema_slow)<float(x.ema_slow.iloc[i-12]) and price<float(r.ema_entry)
        vol=float(r.volume)>=float(r.vol_sma)*p.volume_mult
        mom=p.rsi_min<=float(r.rsi)<=p.rsi_max
        volatility=p.atr_pct_min<=atr_pct<=p.atr_pct_max
        breakdown=price<float(r.prior_low); extension=max(0.,float(r.prior_low)-price)
        stop=max(float(r.swing_high),price+atr*p.atr_stop_floor); dist=stop-price
        stop_ok=dist>=atr*p.atr_stop_floor and dist<=atr*p.atr_stop_cap
        if regime and vol and mom and volatility and float(r.adx)>=p.adx_min and breakdown and extension<=atr*p.max_extension_atr and stop_ok:
            pending={'signal_time':ts,'structural_stop':stop,'atr':atr}
    tdf=pd.DataFrame([asdict(t) for t in trades])
    if len(tdf):
        peak=np.maximum.accumulate(np.r_[initial_cash,tdf.equity_after.values]); vals=np.r_[initial_cash,tdf.equity_after.values]
        maxdd=float(np.min(vals/peak-1))
        wins=int((tdf.net_pnl>0).sum()); gross_win=float(tdf.loc[tdf.net_pnl>0,'net_pnl'].sum()); gross_loss=float(-tdf.loc[tdf.net_pnl<0,'net_pnl'].sum())
    else: maxdd=0.; wins=0; gross_win=gross_loss=0.
    summary={'initial_cash':initial_cash,'ending_equity':eq,'net_pnl':eq-initial_cash,'return_pct':(eq/initial_cash-1)*100,'trades':len(tdf),'win_rate_pct':100*wins/len(tdf) if len(tdf) else 0,'profit_factor':gross_win/gross_loss if gross_loss else None,'max_drawdown_pct':maxdd*100,'fee_per_side':fee,'slippage':slippage,'params':asdict(p)}
    return tdf,summary


def audit_data(df:pd.DataFrame,expected='1h')->dict:
    delta=df.index.to_series().diff().dropna(); exp=pd.Timedelta(expected)
    return {'rows':len(df),'start':str(df.index.min()),'end':str(df.index.max()),'duplicates':int(df.index.duplicated().sum()),'gaps':int((delta!=exp).sum()),'max_gap':str(delta.max()) if len(delta) else None,'nan_cells':int(df.isna().sum().sum()),'negative_volume':int((df.volume<0).sum()),'timezone':str(df.index.tz),'median_interval':str(delta.median()) if len(delta) else None}


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('csv',type=Path); ap.add_argument('--out',type=Path,required=True); ap.add_argument('--fee',type=float,default=.0004); ap.add_argument('--slippage',type=float,default=.0001); ap.add_argument('--cash',type=float,default=100000.)
    a=ap.parse_args(); a.out.mkdir(parents=True,exist_ok=True); df=load_ohlcv(a.csv); audit=audit_data(df); trades,summary=backtest_short(df,initial_cash=a.cash,fee=a.fee,slippage=a.slippage)
    trades.to_csv(a.out/'trades.csv',index=False); (a.out/'summary.json').write_text(json.dumps(summary,indent=2)); (a.out/'data_audit.json').write_text(json.dumps(audit,indent=2)); print(json.dumps({'audit':audit,'summary':summary},indent=2))
if __name__=='__main__': main()
