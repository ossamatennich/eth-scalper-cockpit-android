from __future__ import annotations

import math
from dataclasses import replace

import pandas as pd
import pytest

import v233_research_engine as eng


def _ohlcv(periods: int = 16, freq: str = "1h") -> pd.DataFrame:
    idx = pd.date_range("2024-07-17T00:00:00Z", periods=periods, freq=freq)
    base = pd.Series(range(periods), index=idx, dtype=float) + 100.0
    return pd.DataFrame(
        {
            "open": base,
            "high": base + 1.0,
            "low": base - 1.0,
            "close": base + 0.25,
            "volume": 1000.0,
        },
        index=idx,
    )


def test_true_4h_regime_has_no_lookahead() -> None:
    one = _ohlcv(16)
    p = replace(
        eng.Params(),
        ema_entry=2,
        ema_regime_fast=2,
        ema_regime_slow=3,
        donchian_period=2,
        swing_period=2,
        atr_period=2,
        adx_period=2,
        rsi_period=2,
        volume_period=2,
    )
    x = eng.add_indicators(one, p)
    # The 4h candle starting 08:00 is not usable by the 10:00 signal close.
    assert x.loc[pd.Timestamp("2024-07-17T09:00:00Z"), "regime_available_time"] <= pd.Timestamp(
        "2024-07-17T08:00:00Z"
    )
    # At 11:00, the 1h signal closes at 12:00 and may use the 08:00-12:00 4h candle.
    assert x.loc[pd.Timestamp("2024-07-17T11:00:00Z"), "regime_available_time"] == pd.Timestamp(
        "2024-07-17T12:00:00Z"
    )


def test_stop_and_target_gap_fill_rules() -> None:
    assert eng.trigger_fill("LONG", "STOP", 95.0, 98.0, 0.0) == 95.0
    assert eng.trigger_fill("SHORT", "STOP", 105.0, 102.0, 0.0) == 105.0
    # Favorable target gaps are not granted extra improvement.
    assert eng.trigger_fill("LONG", "TARGET", 110.0, 105.0, 0.0) == 105.0
    assert eng.trigger_fill("SHORT", "TARGET", 90.0, 95.0, 0.0) == 95.0


def _enriched(side: eng.Side) -> pd.DataFrame:
    idx = pd.date_range("2024-07-17T00:00:00Z", periods=5, freq="1h")
    if side == "LONG":
        opens = [100, 100, 100, 100, 100]
        highs = [101, 101, 106, 101, 101]
        lows = [99, 99, 97, 99, 99]
        closes = [100, 100, 100, 100, 100]
        values = dict(
            ema_entry=99.0,
            prior_low=95.0,
            prior_high=99.0,
            swing_high=102.0,
            swing_low=98.0,
            regime_fast=110.0,
            regime_slow=100.0,
            regime_fast_prev=109.0,
            regime_slow_prev3=99.0,
            rsi=60.0,
        )
    else:
        opens = [100, 100, 100, 100, 100]
        highs = [101, 101, 103, 101, 101]
        lows = [99, 99, 94, 99, 99]
        closes = [100, 100, 100, 100, 100]
        values = dict(
            ema_entry=101.0,
            prior_low=101.0,
            prior_high=105.0,
            swing_high=102.0,
            swing_low=98.0,
            regime_fast=90.0,
            regime_slow=100.0,
            regime_fast_prev=91.0,
            regime_slow_prev3=101.0,
            rsi=40.0,
        )
    df = pd.DataFrame(
        {
            "open": opens,
            "high": highs,
            "low": lows,
            "close": closes,
            "volume": 120.0,
            "atr": 1.0,
            "adx": 30.0,
            "volume_sma": 100.0,
            **{k: [v] * 5 for k, v in values.items()},
        },
        index=idx,
    )
    df.index.name = "timestamp"
    return df


@pytest.mark.parametrize("side", ["LONG", "SHORT"])
def test_long_short_backtests_execute_and_ambiguous_bar_uses_stop(monkeypatch: pytest.MonkeyPatch, side: eng.Side) -> None:
    enriched = _enriched(side)
    monkeypatch.setattr(eng, "add_indicators", lambda *args, **kwargs: enriched)
    p = replace(eng.Params(), cooldown_bars=8)
    trades, _, summary = eng.run_backtest(enriched[["open", "high", "low", "close", "volume"]], p, side, slippage=0.0)
    assert len(trades) == 1
    assert trades.iloc[0].side == side
    assert trades.iloc[0].exit_reason == "STOP"
    assert summary["trades"] == 1
    assert summary["long_trades"] == (1 if side == "LONG" else 0)
    assert summary["short_trades"] == (1 if side == "SHORT" else 0)


def test_parameter_neighbourhood_is_compact_and_predeclared() -> None:
    grid = eng.neighbor_grid(eng.Params(), "V070_MTF")
    assert len(grid) == 27
    assert {p.reward_risk for p in grid} == {2.2, 2.6, 3.0}
    assert {p.adx_min for p in grid} == {20.0, 22.0, 24.0}
    assert {p.volume_mult for p in grid} == {1.0, 1.1, 1.2}
    assert {p.atr_stop_floor for p in grid} == {1.6}


def test_trade_window_blocks_warmup_entries(monkeypatch: pytest.MonkeyPatch) -> None:
    enriched = _enriched("LONG")
    monkeypatch.setattr(eng, "add_indicators", lambda *args, **kwargs: enriched)
    p = replace(eng.Params(), cooldown_bars=8)
    trades, curve, summary = eng.run_backtest(
        enriched[["open", "high", "low", "close", "volume"]],
        p,
        "LONG",
        slippage=0.0,
        trade_start="2024-07-17T02:00:00Z",
        trade_end="2024-07-17T05:00:00Z",
    )
    # The signal at 00:00 cannot create a position during warm-up.
    assert trades.empty
    assert curve.index.min() == pd.Timestamp("2024-07-17T00:00:00Z")
    assert summary["trades"] == 0


def test_rsi_handles_one_directional_series() -> None:
    up = _ohlcv(20)
    down = up.iloc[::-1].copy()
    down.index = up.index
    p = replace(eng.Params(), rsi_period=3, ema_regime_fast=2, ema_regime_slow=3)
    up_features = eng.add_indicators(up, p)
    down_features = eng.add_indicators(down, p)
    assert up_features.rsi.dropna().iloc[-1] == 100.0
    assert down_features.rsi.dropna().iloc[-1] == 0.0


def test_natural_synthetic_path_executes_long_short_and_both() -> None:
    import numpy as np

    idx = pd.date_range("2024-07-17", periods=240, freq="1h", tz="UTC")
    close = np.r_[np.linspace(100, 180, 120), np.linspace(180, 90, 120)]
    open_ = np.r_[close[0], close[:-1]]
    data = pd.DataFrame(
        {
            "open": open_,
            "high": np.maximum(open_, close) + 1,
            "low": np.minimum(open_, close) - 1,
            "close": close,
            "volume": 1000.0,
        },
        index=idx,
    )
    p = replace(
        eng.Params(),
        strategy_kind="EMA_TREND_SIMPLE",
        ema_entry=3,
        ema_regime_fast=2,
        ema_regime_slow=3,
        donchian_period=3,
        swing_period=3,
        atr_period=3,
        adx_period=3,
        rsi_period=3,
        volume_period=3,
        adx_min=0,
        volume_mult=0,
        atr_pct_min=0,
        atr_pct_max=1,
        atr_stop_floor=0.5,
        atr_stop_cap=10,
        reward_risk=1.5,
        max_hold_bars=4,
        cooldown_bars=2,
        breakeven_r=10,
        trail_start_r=10,
    )
    summaries = {mode: eng.run_backtest(data, p, mode)[2] for mode in ("LONG", "SHORT", "BOTH")}
    assert summaries["LONG"]["long_trades"] > 0 and summaries["LONG"]["short_trades"] == 0
    assert summaries["SHORT"]["short_trades"] > 0 and summaries["SHORT"]["long_trades"] == 0
    assert summaries["BOTH"]["long_trades"] > 0 and summaries["BOTH"]["short_trades"] > 0


def test_risk_sizing_includes_fees_and_stop_slippage(monkeypatch: pytest.MonkeyPatch) -> None:
    enriched = _enriched("LONG")
    monkeypatch.setattr(eng, "add_indicators", lambda *args, **kwargs: enriched)
    p = replace(eng.Params(), cooldown_bars=8, risk_pct=0.0015)
    trades, _, _ = eng.run_backtest(
        enriched[["open", "high", "low", "close", "volume"]],
        p,
        "LONG",
        fee_per_side=0.0004,
        slippage=0.0001,
    )
    assert len(trades) == 1
    # Initial equity 100k * 0.15% = 150 risk budget. Floating point and a
    # conservative gap model may make the realized stop loss slightly smaller.
    assert -trades.iloc[0].net_pnl <= 150.000001
    assert trades.iloc[0].risk_budget_per_unit > trades.iloc[0].initial_risk


def test_final_oos_not_opened_without_validation_lock(monkeypatch: pytest.MonkeyPatch, tmp_path) -> None:
    calls: list[str | None] = []

    def fake_run(*args, trade_start=None, **kwargs):
        calls.append(str(trade_start) if trade_start is not None else None)
        summary = {
            "trades": 0,
            "return_pct": 0.0,
            "profit_factor": None,
            "max_drawdown_pct": 0.0,
            "expectancy_r": 0.0,
        }
        return pd.DataFrame(), pd.DataFrame(), summary

    monkeypatch.setattr(eng, "run_backtest", fake_run)
    idx = pd.date_range("2024-07-17", periods=2, freq="1h", tz="UTC")
    corpus = pd.DataFrame(
        {"open": [1.0, 1.0], "high": [1.0, 1.0], "low": [1.0, 1.0], "close": [1.0, 1.0], "volume": [1.0, 1.0]},
        index=idx,
    )
    report = eng.run_research(corpus, tmp_path)
    assert report["validation_candidate_locked"] is False
    assert report["final_oos_evaluated"] is False
    assert report["final_oos"]["status"] == "NOT_EVALUATED_NO_VALIDATION_CANDIDATE"
    assert "2026-03-01 00:00:00+00:00" not in calls
