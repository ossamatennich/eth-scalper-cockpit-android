from __future__ import annotations

from pathlib import Path

import apply_v2326_stale_risk_separation as patcher


def test_java_semantics_monitor_existing_risk_before_stale_gate() -> None:
    patcher.verify_text(patcher.NEW_JAVA)
    assert patcher.NEW_JAVA.index("updateObservedSignals(snapshot, now);") < patcher.NEW_JAVA.index(
        "if (!ethExecutionFeedFresh(now))"
    )
    assert "surveillance TP/SL active maintenue" in patcher.NEW_JAVA
    assert "aucune entrée ni sortie simulée" not in patcher.NEW_JAVA


def test_candidate_script_patch_is_idempotent(tmp_path: Path) -> None:
    target = tmp_path / "apply_v2326_candidate_COPY.py"
    target.write_text(patcher.OLD_SCRIPT_FRAGMENT, encoding="utf-8")
    patcher.replace_exact(target, patcher.OLD_SCRIPT_FRAGMENT, patcher.NEW_SCRIPT_FRAGMENT)
    patcher.verify_candidate_script(target.read_text(encoding="utf-8"))
    assert patcher.NEW_SCRIPT_FRAGMENT in target.read_text(encoding="utf-8")
