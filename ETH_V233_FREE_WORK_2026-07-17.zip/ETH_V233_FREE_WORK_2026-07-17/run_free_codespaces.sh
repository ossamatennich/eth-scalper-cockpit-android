#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

PYTHON_BIN="${PYTHON_BIN:-python3}"
"$PYTHON_BIN" -m venv .venv
# shellcheck disable=SC1091
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install pandas numpy pyarrow pytest

pytest -q

CORPUS_DIR="$ROOT/ETHUSDT_UM_CORPUS_2024-07-17_2026-07-16"
RESULTS_DIR="$ROOT/V233_RESEARCH_RESULTS"
python binance_corpus_builder.py --output "$CORPUS_DIR"
python v233_research_engine.py \
  "$CORPUS_DIR/clean/ETHUSDT_UM_1h_2024-07-17_2026-07-16.parquet" \
  --output "$RESULTS_DIR" \
  --fee 0.0004 \
  --slippage 0.0001

python - <<'PY'
from pathlib import Path
import json

root = Path.cwd()
corpus = json.loads((root / "ETHUSDT_UM_CORPUS_2024-07-17_2026-07-16" / "CORPUS_AUDIT.json").read_text())
report = json.loads((root / "V233_RESEARCH_RESULTS" / "RESEARCH_REPORT.json").read_text())
assert corpus["status"] == "PASS", corpus
assert corpus["audit_1h"]["rows"] == 17520, corpus["audit_1h"]
assert corpus["audit_4h_native"]["rows"] == 4380, corpus["audit_4h_native"]
assert corpus["audit_1h"]["missing_count"] == 0
assert corpus["audit_4h_native"]["missing_count"] == 0
assert corpus["native_vs_resampled_4h"]["price_mismatch_rows"] == 0
assert corpus["native_vs_resampled_4h"]["volume_mismatch_rows"] == 0
assert report["research_only"] is True
assert report["android_integration_allowed"] is False
print(json.dumps({
    "corpus_status": corpus["status"],
    "rows_1h": corpus["audit_1h"]["rows"],
    "rows_4h": corpus["audit_4h_native"]["rows"],
    "research_only": report["research_only"],
    "stable": report["stable"],
    "android_integration_allowed": report["android_integration_allowed"],
}, indent=2))
PY

python - <<'PY'
from pathlib import Path
import hashlib
import zipfile

root = Path.cwd()
out = root / "ETH_V233_FREE_RESEARCH_OUTPUT.zip"
paths = [
    root / "ETHUSDT_UM_CORPUS_2024-07-17_2026-07-16" / "CORPUS_AUDIT.json",
    root / "ETHUSDT_UM_CORPUS_2024-07-17_2026-07-16" / "SPLITS.json",
    root / "ETHUSDT_UM_CORPUS_2024-07-17_2026-07-16" / "clean",
    root / "V233_RESEARCH_RESULTS",
]
with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
    for path in paths:
        if path.is_dir():
            for f in sorted(path.rglob("*")):
                if f.is_file():
                    zf.write(f, f.relative_to(root))
        else:
            zf.write(path, path.relative_to(root))
h = hashlib.sha256(out.read_bytes()).hexdigest()
(out.with_suffix(out.suffix + ".sha256")).write_text(f"{h}  {out.name}\n", encoding="utf-8")
print(f"OUTPUT={out}")
print(f"SHA256={h}")
PY
