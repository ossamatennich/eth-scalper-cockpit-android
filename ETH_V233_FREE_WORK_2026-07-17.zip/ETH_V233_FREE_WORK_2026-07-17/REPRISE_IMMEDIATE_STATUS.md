# ETH Scalper Cockpit v2.33 — Reprise immédiate

Date UTC: 2026-07-17
Statut global: RESEARCH_ONLY

## Réalisé
- Relais principal et sous-archives intégralement extraits.
- Vérification SHA-256: 25/25 fichiers conformes.
- Six diagnostics consolidés: 9 265 frames, 9 signaux, 9 observations terminales, aucune corruption JSON/JSONL.
- Patch sûr v2.32.6 comparé au paquet candidat ancien.
- Garde V2326_ETH_FEED_STALE confirmée dans le dernier diagnostic.
- Backtester événementiel local déterministe créé avec frais, slippage, taille par risque, SL/TP explicites, gaps, règle SL-first, BE, trailing, timeout et cooldown.
- Tests automatisés: 3/3 réussis.
- Stratégie LONA v0.7.0 recréée dans LONA pour audit.

## Constats bloquants
- Le connecteur LONA échoue au téléchargement et au backtest avec `frequency: undefined`; 0 crédit consommé.
- Le jeu global LONA ETHUSD ne restitue pas ses données (`Not Found`) et n'est pas utilisable comme source propre.
- Le connecteur Binance restitue les klines Futures ETHUSDT, mais ne fournit pas de transfert de fichier vers le runtime; le réseau sortant du runtime est bloqué au niveau DNS pour Binance Vision/Kaggle.
- Le corpus propre complet 1h/4h 2024-07-17 → 2026-07-16 n'est donc pas encore matérialisé localement.

## Défauts de la stratégie v0.7.0
- Elle n'est pas réellement 4H régime / 1H exécution: EMA80/EMA200 calculées sur `self.data` unique.
- Les sorties Backtrader par `close()` après détection SL/TP ne garantissent pas un fill au seuil détecté.
- Aucun résultat de rentabilité ne peut être accepté avant correction multi-timeframe et backtest sur données propres.

## Gate
- Aucun code Android v2.33 intégré à ce stade.
- RESEARCH_ONLY maintenu.
- Étape suivante autorisée uniquement après matérialisation et audit du corpus Binance 1h/4h, puis exécution train/validation/final avec grilles de frais/slippage et tests LONG/SHORT séparés.
