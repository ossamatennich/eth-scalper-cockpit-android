#!/usr/bin/env python3
"""Correct v2.32.6 stale-feed semantics without integrating the intraday engine.

Safety rule:
- stale ETH execution feed blocks creation/evaluation of NEW entries;
- lifecycle monitoring of already-observed/active trades always runs first, so TP/SL,
  invalidation and timeout handling cannot be skipped by the stale-entry guard.

The script can patch either MarketWatchService.java (already at candidate v2.32.6)
or the relay's apply_v2326_candidate.py so a future source application is correct.
"""
from __future__ import annotations

import argparse
from pathlib import Path

OLD_JAVA = '''    private synchronized void evaluateSignal(long now) {
        MarketSnapshot snapshot = buildSnapshot(now);

        if (!ethExecutionFeedFresh(now)) {
            SignalDecision staleFeed = SignalDecision.waiting(
                    "V2326_ETH_FEED_STALE",
                    "Signal bloqué : prix ETH temps réel trop ancien",
                    0, "", false, 0, 0, 0, false);
            recordMarketFrame(snapshot, staleFeed, now);
            lastDecision = staleFeed;
            broadcastStatus("eth_feed_stale", "Prix ETH temps réel trop ancien : aucune entrée ni sortie simulée");
            return;
        }

        updateObservedSignals(snapshot, now);

        SignalDecision rawDecision = signalEngine.evaluate(snapshot);
'''

NEW_JAVA = '''    private synchronized void evaluateSignal(long now) {
        MarketSnapshot snapshot = buildSnapshot(now);

        // v2.32.6 safety separation: an existing trade/observation must always be
        // monitored before the new-entry freshness gate. Stale market data may
        // prevent a new decision, but must never suspend TP/SL/invalidation/timeout.
        updateObservedSignals(snapshot, now);

        if (!ethExecutionFeedFresh(now)) {
            SignalDecision staleFeed = SignalDecision.waiting(
                    "V2326_ETH_FEED_STALE",
                    "Nouvelle entrée bloquée : prix ETH temps réel trop ancien",
                    0, "", false, 0, 0, 0, false);
            recordMarketFrame(snapshot, staleFeed, now);
            lastDecision = staleFeed;
            broadcastStatus(
                    "eth_feed_stale_new_entries_blocked",
                    "Flux ETH périmé : nouvelles entrées bloquées, surveillance TP/SL active maintenue");
            return;
        }

        SignalDecision rawDecision = signalEngine.evaluate(snapshot);
'''

OLD_SCRIPT_FRAGMENT = '''    new_eval = \'\'\'    private synchronized void evaluateSignal(long now) {
        MarketSnapshot snapshot = buildSnapshot(now);

        if (!ethExecutionFeedFresh(now)) {
            SignalDecision staleFeed = SignalDecision.waiting(
                    "V2326_ETH_FEED_STALE",
                    "Signal bloqué : prix ETH temps réel trop ancien",
                    0, "", false, 0, 0, 0, false);
            recordMarketFrame(snapshot, staleFeed, now);
            lastDecision = staleFeed;
            broadcastStatus("eth_feed_stale", "Prix ETH temps réel trop ancien : aucune entrée ni sortie simulée");
            return;
        }

        updateObservedSignals(snapshot, now);

        SignalDecision rawDecision = signalEngine.evaluate(snapshot);
\'\'\'
'''

NEW_SCRIPT_FRAGMENT = '''    new_eval = \'\'\'    private synchronized void evaluateSignal(long now) {
        MarketSnapshot snapshot = buildSnapshot(now);

        // v2.32.6 safety separation: always manage existing risk first.
        updateObservedSignals(snapshot, now);

        if (!ethExecutionFeedFresh(now)) {
            SignalDecision staleFeed = SignalDecision.waiting(
                    "V2326_ETH_FEED_STALE",
                    "Nouvelle entrée bloquée : prix ETH temps réel trop ancien",
                    0, "", false, 0, 0, 0, false);
            recordMarketFrame(snapshot, staleFeed, now);
            lastDecision = staleFeed;
            broadcastStatus(
                    "eth_feed_stale_new_entries_blocked",
                    "Flux ETH périmé : nouvelles entrées bloquées, surveillance TP/SL active maintenue");
            return;
        }

        SignalDecision rawDecision = signalEngine.evaluate(snapshot);
\'\'\'
'''


def replace_exact(path: Path, old: str, new: str) -> None:
    text = path.read_text(encoding="utf-8")
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f"{path}: expected exactly one candidate block, found {count}")
    path.write_text(text.replace(old, new, 1), encoding="utf-8")


def verify_text(text: str) -> None:
    update_pos = text.find("updateObservedSignals(snapshot, now);")
    guard_pos = text.find("if (!ethExecutionFeedFresh(now))")
    decision_pos = text.find("SignalDecision rawDecision = signalEngine.evaluate(snapshot);")
    if min(update_pos, guard_pos, decision_pos) < 0:
        raise RuntimeError("Required lifecycle/guard/decision markers missing")
    if not update_pos < guard_pos < decision_pos:
        raise RuntimeError("Unsafe order: lifecycle monitoring must precede stale gate and new decision")
    forbidden = "aucune entrée ni sortie simulée"
    if forbidden in text:
        raise RuntimeError(f"Unsafe stale message still present: {forbidden}")
    if "surveillance TP/SL active maintenue" not in text:
        raise RuntimeError("Explicit active-risk monitoring status missing")


def verify_candidate_script(text: str) -> None:
    marker = "    new_eval = '''"
    start = text.find(marker)
    if start < 0:
        raise RuntimeError("new_eval candidate block missing")
    start += len(marker)
    end = text.find("\n'''", start)
    if end < 0:
        raise RuntimeError("new_eval candidate block is unterminated")
    verify_text(text[start:end])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("path", type=Path, help="MarketWatchService.java or apply_v2326_candidate.py")
    args = parser.parse_args()
    text = args.path.read_text(encoding="utf-8")
    if args.path.name == "MarketWatchService.java":
        replace_exact(args.path, OLD_JAVA, NEW_JAVA)
    elif args.path.suffix == ".py" and "apply_v2326_candidate" in args.path.name:
        if OLD_SCRIPT_FRAGMENT in text:
            replace_exact(args.path, OLD_SCRIPT_FRAGMENT, NEW_SCRIPT_FRAGMENT)
        elif NEW_SCRIPT_FRAGMENT not in text:
            raise RuntimeError("Candidate script contains neither the unsafe nor corrected evaluation block")
    else:
        raise SystemExit("Unsupported file; pass MarketWatchService.java or apply_v2326_candidate.py")
    patched = args.path.read_text(encoding="utf-8")
    if args.path.name == "MarketWatchService.java":
        verify_text(patched)
    else:
        verify_candidate_script(patched)
    print(f"PATCHED_AND_VERIFIED {args.path}")


if __name__ == "__main__":
    main()
