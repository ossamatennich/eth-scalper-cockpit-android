from __future__ import annotations

import hashlib
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from binance_historical_extension import (
    EXPECTED_1H, EXPECTED_4H, PREHOLDOUT_END, START, archive_url, compare_4h,
    derive_4h, deterministic_null_repair, month_starts, parse_checksum, validate_ohlcv,
)
from v233_false_breakout_architectures import (
    Spec, central_specs, load_ohlcv, one_at_a_time_neighbours, prepare_features,
    run_backtest, setup_events,
)
from v233_historical_nested_validation import bootstrap_iid, monte_carlo_order, verify_lock


def candles(start="2025-01-01", periods=500, freq="1h", drift=0.3):
    idx = pd.date_range(start, periods=periods, freq=freq, tz="UTC")
    close = 1000 + np.arange(periods) * drift + np.sin(np.arange(periods) / 8) * 3
    return pd.DataFrame({"open": close - 0.2, "high": close + 2, "low": close - 2, "close": close,
                         "volume": np.full(periods, 1000.0)}, index=idx)


def test_expected_coverage_and_months():
    assert EXPECTED_1H == int((PREHOLDOUT_END - START) / pd.Timedelta(hours=1)) == 47448
    assert EXPECTED_4H == int((PREHOLDOUT_END - START) / pd.Timedelta(hours=4)) == 11862
    months = month_starts()
    assert len(months) == 65
    assert months[0] == START
    assert months[-1] == pd.Timestamp("2026-05-01", tz="UTC")
    assert all("2026-06" not in archive_url("1h", m) for m in months)


def test_checksum_parser():
    name = "ETHUSDT-1h-2021-01.zip"
    digest = "a" * 64
    assert parse_checksum(f"{digest}  {name}\n", name) == digest
    with pytest.raises(ValueError):
        parse_checksum("invalid", name)


def test_deterministic_null_repair_only_when_unique():
    x = candles(periods=5)
    missing = x.drop(x.index[2])
    # Force continuity across the missing boundary.
    missing.loc[x.index[3], "open"] = missing.loc[x.index[1], "close"]
    fixed, repairs = deterministic_null_repair(missing, "1h")
    assert len(fixed) == 5 and len(repairs) == 1
    assert fixed.loc[x.index[2], "open"] == fixed.loc[x.index[2], "close"]
    bad = x.drop(x.index[2])
    with pytest.raises(ValueError):
        deterministic_null_repair(bad, "1h")


def test_native_derived_4h_exact_crosscheck():
    x = candles(periods=24)
    d = derive_4h(x)
    c = compare_4h(d, d.copy())
    assert c["price_mismatch_rows"] == 0
    assert c["volume_mismatch_rows"] == 0


def test_ohlcv_audit_detects_no_missing():
    x = candles(start="2021-01-01", periods=24)
    a = validate_ohlcv(x, pd.Timestamp("2021-01-01", tz="UTC"), pd.Timestamp("2021-01-02", tz="UTC"), "1h")
    assert a["missing_count"] == 0 and a["invalid_ohlcv_count"] == 0


def test_lock_hashes_are_valid():
    for name in ("LOCKED_ARCHITECTURES_V2.json", "LOCKED_CRITERIA_V2.json"):
        p = ROOT / "protocol" / name
        assert verify_lock(p) == hashlib.sha256(p.read_bytes()).hexdigest()


def test_exactly_four_architectures_and_two_sides():
    specs = central_specs()
    assert len(specs) == 8
    assert {s.side for s in specs} == {"LONG", "SHORT"}
    assert {s.architecture for s in specs} == {"BASE_DONCHIAN", "CONTINUOUS_REGIME", "BREAKOUT_CONFIRMATION", "BREAKOUT_RETEST"}


def test_neighbours_are_one_dimension_at_a_time():
    central = Spec("BREAKOUT_RETEST", "LONG")
    for n in one_at_a_time_neighbours(central):
        diffs = sum(getattr(n, k) != getattr(central, k) for k in central.__dataclass_fields__)
        assert diffs <= 1


def test_closed_4h_availability_has_no_lookahead():
    f = prepare_features(candles(periods=300))
    valid = f.h4_available_time.dropna()
    signal_close = valid.index + pd.Timedelta(hours=1)
    assert (valid <= signal_close).all()
    # A 4h candle opened at T cannot be available before T+4h.
    assert ((valid.dt.hour % 4) == 0).all()


def test_confirmation_and_retest_are_not_same_bar_entries():
    f = prepare_features(candles(periods=400, drift=0.5))
    for arch in ("BREAKOUT_CONFIRMATION", "BREAKOUT_RETEST"):
        events = setup_events(f, Spec(arch, "LONG", confirmation_bars=1, retest_window_bars=3))
        assert all(e["complete_i"] > e["signal_i"] for e in events)


def test_holdout_firewall_on_load(tmp_path):
    x = candles(start="2026-05-31", periods=72).reset_index(names="timestamp")
    p = tmp_path / "x.csv"
    x.to_csv(p, index=False)
    z = load_ohlcv(p)
    assert len(z) == 24
    assert z.index.max() == pd.Timestamp("2026-05-31T23:00:00Z")


def test_backtest_refuses_end_after_holdout():
    f = prepare_features(candles(start="2025-01-01", periods=1000, drift=0.5))
    with pytest.raises(ValueError):
        run_backtest(f, Spec("BASE_DONCHIAN", "LONG"), f.index[0], pd.Timestamp("2026-06-02", tz="UTC"))


def test_bootstrap_and_monte_carlo_deterministic():
    r = np.array([1.0, -0.5, 0.8, -0.2, 1.2])
    assert bootstrap_iid(r, n=1000, seed=7) == bootstrap_iid(r, n=1000, seed=7)
    assert monte_carlo_order(r, n=1000, seed=7) == monte_carlo_order(r, n=1000, seed=7)


def _minimal_backtest_frame():
    idx = pd.date_range("2025-01-01", periods=4, freq="1h", tz="UTC")
    return pd.DataFrame({
        "open": [100.0, 100.0, 101.0, 101.0],
        "high": [100.5, 103.0, 103.0, 101.5],
        "low": [99.5, 98.0, 100.0, 100.5],
        "close": [100.0, 101.0, 102.0, 101.0],
        "atr": [1.0, 1.0, 1.0, 1.0],
        "market_regime": ["RANGE"] * 4,
        "vol_regime": ["MID"] * 4,
        "h4_trend_score": [0.0] * 4,
    }, index=idx)


def test_entry_bar_is_exposed_and_stop_first(monkeypatch):
    import v233_false_breakout_architectures as engine
    f = _minimal_backtest_frame()
    monkeypatch.setattr(engine, "setup_events", lambda _f, _s: [{"complete_i": 0, "signal_i": 0, "stop": 99.0, "risk_scale": 1.0}])
    t, _ = engine.run_backtest(f, engine.Spec("BASE_DONCHIAN", "LONG", reward_risk=2.0), f.index[0], f.index[-1] + pd.Timedelta(hours=1))
    assert len(t) == 1
    assert t.iloc[0].exit_reason == "STOP"
    assert t.iloc[0].bars_held == 1


def test_max_hold_exits_at_open_before_intrabar_target(monkeypatch):
    import v233_false_breakout_architectures as engine
    f = _minimal_backtest_frame()
    # First entry bar cannot hit either boundary; second bar reaches the target intrabar,
    # but max_hold=2 requires an open exit before that high is observed.
    f.loc[f.index[1], ["high", "low"]] = [101.0, 99.5]
    monkeypatch.setattr(engine, "setup_events", lambda _f, _s: [{"complete_i": 0, "signal_i": 0, "stop": 99.0, "risk_scale": 1.0}])
    spec = engine.Spec("BASE_DONCHIAN", "LONG", reward_risk=2.0, max_hold_bars=2)
    t, _ = engine.run_backtest(f, spec, f.index[0], f.index[-1] + pd.Timedelta(hours=1))
    assert len(t) == 1
    assert t.iloc[0].exit_reason == "MAX_HOLD"
    assert abs(t.iloc[0].exit - (f.iloc[2].open * (1 - 0.0001))) < 1e-9
