#!/usr/bin/env python3
"""Locked false-breakout architecture engine for ETH v2.33 research.

No holdout access. Signals use closed 1h candles and closed 4h context only.
"""
from __future__ import annotations

import math
from dataclasses import asdict, dataclass, replace
from pathlib import Path
from typing import Literal

import numpy as np
import pandas as pd

Side = Literal["LONG", "SHORT"]
Architecture = Literal["BASE_DONCHIAN", "CONTINUOUS_REGIME", "BREAKOUT_CONFIRMATION", "BREAKOUT_RETEST"]
PREHOLDOUT_END = pd.Timestamp("2026-06-01T00:00:00Z")


@dataclass(frozen=True)
class Spec:
    architecture: Architecture
    side: Side
    channel_bars: int = 24
    swing_bars: int = 12
    atr_period: int = 14
    atr_stop_mult: float = 1.8
    atr_stop_cap: float = 3.2
    reward_risk: float = 2.4
    regime_threshold: float = 0.35
    confirmation_bars: int = 1
    retest_window_bars: int = 3
    retest_tolerance_atr: float = 0.15
    risk_pct: float = 0.0015
    max_leverage: float = 1.0
    breakeven_r: float = 1.2
    trail_start_r: float = 1.8
    trail_atr_mult: float = 2.0
    max_hold_bars: int = 14
    cooldown_bars: int = 6


def load_ohlcv(path: Path, hard_end: pd.Timestamp = PREHOLDOUT_END) -> pd.DataFrame:
    x = pd.read_parquet(path) if path.suffix == ".parquet" else pd.read_csv(path)
    lower = {str(c).lower(): c for c in x.columns}
    time_col = next((lower[k] for k in ("timestamp", "open_time", "datetime", "date", "time") if k in lower), None)
    if time_col is None:
        raise ValueError("timestamp column missing")
    rename = {time_col: "timestamp"}
    for c in ("open", "high", "low", "close", "volume"):
        if c not in lower:
            raise ValueError(f"{c} missing")
        rename[lower[c]] = c
    x = x.rename(columns=rename)[["timestamp", "open", "high", "low", "close", "volume"]].copy()
    if pd.api.types.is_numeric_dtype(x.timestamp):
        med = float(pd.to_numeric(x.timestamp, errors="coerce").dropna().median())
        x.timestamp = pd.to_datetime(x.timestamp, unit="us" if med > 1e14 else ("ms" if med > 1e11 else "s"), utc=True, errors="coerce")
    else:
        x.timestamp = pd.to_datetime(x.timestamp, utc=True, errors="coerce")
    for c in ("open", "high", "low", "close", "volume"):
        x[c] = pd.to_numeric(x[c], errors="coerce")
    x = x.dropna().sort_values("timestamp")
    # Firewall is applied immediately, before features or statistics.
    x = x[x.timestamp < hard_end]
    if x.timestamp.duplicated().any():
        raise ValueError("duplicate timestamps")
    x = x.set_index("timestamp")
    if len(x) and x.index.max() >= hard_end:
        raise AssertionError("sealed holdout entered research frame")
    bad = ((x[["open", "high", "low", "close"]] <= 0).any(axis=1) | (x.volume < 0)
           | (x.high < x[["open", "close"]].max(axis=1)) | (x.low > x[["open", "close"]].min(axis=1)) | (x.high < x.low))
    if bad.any():
        raise ValueError(f"invalid OHLCV rows: {int(bad.sum())}")
    return x


def wilder(s: pd.Series, n: int) -> pd.Series:
    return s.ewm(alpha=1 / n, adjust=False, min_periods=n).mean()


def atr_adx(x: pd.DataFrame, n: int = 14) -> tuple[pd.Series, pd.Series]:
    prev = x.close.shift(1)
    tr = pd.concat([(x.high - x.low), (x.high - prev).abs(), (x.low - prev).abs()], axis=1).max(axis=1)
    atr = wilder(tr, n)
    up, down = x.high.diff(), -x.low.diff()
    plus = pd.Series(np.where((up > down) & (up > 0), up, 0.0), index=x.index)
    minus = pd.Series(np.where((down > up) & (down > 0), down, 0.0), index=x.index)
    pdi, mdi = 100 * wilder(plus, n) / atr, 100 * wilder(minus, n) / atr
    dx = 100 * (pdi - mdi).abs() / (pdi + mdi).replace(0, np.nan)
    return atr, wilder(dx, n)


def prepare_features(one_h: pd.DataFrame) -> pd.DataFrame:
    x = one_h.copy().sort_index()
    x.index.name = "timestamp"
    x["atr"], x["adx"] = atr_adx(x, 14)
    x["atr_pct"] = x.atr / x.close
    x["ema20"] = x.close.ewm(span=20, adjust=False, min_periods=20).mean()
    x["ema50"] = x.close.ewm(span=50, adjust=False, min_periods=50).mean()
    x["vol_sma24"] = x.volume.rolling(24, min_periods=24).mean()
    for n in (12, 20, 24, 28):
        x[f"prior_high_{n}"] = x.high.shift(1).rolling(n, min_periods=n).max()
        x[f"prior_low_{n}"] = x.low.shift(1).rolling(n, min_periods=n).min()
    for n in (12,):
        x[f"swing_high_{n}"] = x.high.shift(1).rolling(n, min_periods=n).max()
        x[f"swing_low_{n}"] = x.low.shift(1).rolling(n, min_periods=n).min()

    h4 = x[["open", "high", "low", "close", "volume"]].resample("4h", label="left", closed="left", origin="epoch").agg(
        open=("open", "first"), high=("high", "max"), low=("low", "min"), close=("close", "last"), volume=("volume", "sum")
    ).dropna()
    h4["atr"], h4["adx"] = atr_adx(h4, 14)
    h4["ema12"] = h4.close.ewm(span=12, adjust=False, min_periods=12).mean()
    h4["ema36"] = h4.close.ewm(span=36, adjust=False, min_periods=36).mean()
    h4["ema12_prev"] = h4.ema12.shift(1)
    gap = (h4.ema12 - h4.ema36) / h4.atr.replace(0, np.nan)
    slope = (h4.ema12 - h4.ema12_prev) / h4.atr.replace(0, np.nan)
    strength = ((h4.adx - 18.0) / 20.0).clip(-1.0, 1.5)
    # Bounded continuous score; fixed formula, no sample-wide fitting or future quantile.
    h4["trend_score"] = np.tanh(0.75 * gap + 0.55 * slope + 0.25 * np.sign(gap) * strength)
    h4["trend_direction"] = np.where(h4.trend_score > 0.2, "BULL", np.where(h4.trend_score < -0.2, "BEAR", "RANGE"))
    h4["transition"] = (np.sign(h4.trend_score) != np.sign(h4.trend_score.shift(1))) | (h4.trend_score.abs() < 0.2)
    available = h4[["atr", "adx", "trend_score", "trend_direction", "transition"]].copy()
    available.index = available.index + pd.Timedelta(hours=4)
    available.index.name = "h4_available_time"
    signal_close = pd.DataFrame({"signal_close_time": x.index + pd.Timedelta(hours=1)}, index=x.index)
    merged = pd.merge_asof(signal_close.reset_index().sort_values("signal_close_time"),
                           available.reset_index().sort_values("h4_available_time"),
                           left_on="signal_close_time", right_on="h4_available_time", direction="backward").set_index("timestamp")
    for c in available.columns:
        x[f"h4_{c}"] = merged[c].reindex(x.index)
    x["h4_available_time"] = merged.h4_available_time.reindex(x.index)
    # Fixed volatility labels avoid any future-data quantile fitting.
    x["vol_regime"] = np.where(x.atr_pct >= 0.015, "HIGH", np.where(x.atr_pct <= 0.006, "LOW", "MID"))
    transition_mask = x.h4_transition.astype("boolean").fillna(True).to_numpy(dtype=bool)
    x["market_regime"] = np.where(transition_mask, "TRANSITION", x.h4_trend_direction.fillna("RANGE"))
    return x


def adverse(price: float, side: Side, action: str, slip: float) -> float:
    if side == "LONG":
        return price * (1 + slip) if action == "ENTRY" else price * (1 - slip)
    return price * (1 - slip) if action == "ENTRY" else price * (1 + slip)


def trigger_fill(side: Side, kind: str, bar_open: float, level: float, slip: float) -> float:
    raw = (min(bar_open, level) if side == "LONG" else max(bar_open, level)) if kind == "STOP" else level
    return adverse(raw, side, "EXIT", slip)


def _base_breakout(row: pd.Series, spec: Spec) -> tuple[bool, float, float]:
    hi, lo = float(row[f"prior_high_{spec.channel_bars}"]), float(row[f"prior_low_{spec.channel_bars}"])
    atr = float(row.atr)
    common = (np.isfinite(atr) and 0.003 <= float(row.atr_pct) <= 0.04
              and float(row.volume) >= 0.8 * float(row.vol_sma24))
    if spec.side == "LONG":
        br = float(row.close) > hi
        level = hi
        stop = min(float(row[f"swing_low_{spec.swing_bars}"]), float(row.close) - spec.atr_stop_mult * atr)
        distance = float(row.close) - stop
    else:
        br = float(row.close) < lo
        level = lo
        stop = max(float(row[f"swing_high_{spec.swing_bars}"]), float(row.close) + spec.atr_stop_mult * atr)
        distance = stop - float(row.close)
    stop_ok = spec.atr_stop_mult * atr <= distance <= spec.atr_stop_cap * atr
    return bool(common and br and stop_ok), float(level), float(stop)


def setup_events(f: pd.DataFrame, spec: Spec) -> list[dict]:
    """Return completed setup events. Vectorized base conditions, stateful confirmation/retest."""
    close = f.close.to_numpy(float); high = f.high.to_numpy(float); low = f.low.to_numpy(float)
    atr = f.atr.to_numpy(float); atr_pct = f.atr_pct.to_numpy(float)
    volume = f.volume.to_numpy(float); vol_sma = f.vol_sma24.to_numpy(float)
    prior_hi = f[f"prior_high_{spec.channel_bars}"].to_numpy(float)
    prior_lo = f[f"prior_low_{spec.channel_bars}"].to_numpy(float)
    swing_hi = f[f"swing_high_{spec.swing_bars}"].to_numpy(float)
    swing_lo = f[f"swing_low_{spec.swing_bars}"].to_numpy(float)
    common = np.isfinite(atr) & np.isfinite(vol_sma) & (atr_pct >= 0.003) & (atr_pct <= 0.04) & (volume >= 0.8 * vol_sma)
    if spec.side == "LONG":
        breakout = close > prior_hi
        level = prior_hi
        stop = np.minimum(swing_lo, close - spec.atr_stop_mult * atr)
        distance = close - stop
    else:
        breakout = close < prior_lo
        level = prior_lo
        stop = np.maximum(swing_hi, close + spec.atr_stop_mult * atr)
        distance = stop - close
    base = common & breakout & np.isfinite(level) & np.isfinite(stop) & (distance >= spec.atr_stop_mult * atr) & (distance <= spec.atr_stop_cap * atr)
    base[:max(60, spec.channel_bars + 2)] = False
    events: list[dict] = []
    if spec.architecture == "BASE_DONCHIAN":
        for i in np.flatnonzero(base):
            events.append({"signal_i": int(i), "complete_i": int(i), "level": float(level[i]), "stop": float(stop[i]), "risk_scale": 1.0})
        return events
    if spec.architecture == "CONTINUOUS_REGIME":
        score = pd.to_numeric(f.h4_trend_score, errors="coerce").fillna(0.0).to_numpy(float)
        direction_ok = score >= spec.regime_threshold if spec.side == "LONG" else score <= -spec.regime_threshold
        for i in np.flatnonzero(base & direction_ok):
            scale = float(np.clip((abs(score[i]) - spec.regime_threshold) / max(1 - spec.regime_threshold, 1e-9), 0.5, 1.0))
            events.append({"signal_i": int(i), "complete_i": int(i), "level": float(level[i]), "stop": float(stop[i]), "risk_scale": scale})
        return events
    active: dict | None = None
    for i in range(max(60, spec.channel_bars + 2), len(f)):
        if active is not None:
            age = i - active["signal_i"]
            if spec.architecture == "BREAKOUT_CONFIRMATION":
                held = close[i] > active["level"] if spec.side == "LONG" else close[i] < active["level"]
                if age >= spec.confirmation_bars:
                    if held:
                        events.append({**active, "complete_i": i, "risk_scale": 1.0})
                    active = None
            else:
                tol = spec.retest_tolerance_atr * atr[i]
                touched = low[i] <= active["level"] + tol if spec.side == "LONG" else high[i] >= active["level"] - tol
                reclaimed = close[i] > active["level"] if spec.side == "LONG" else close[i] < active["level"]
                if touched and reclaimed:
                    events.append({**active, "complete_i": i, "risk_scale": 1.0}); active = None
                elif age >= spec.retest_window_bars:
                    active = None
        if active is None and base[i]:
            active = {"signal_i": i, "level": float(level[i]), "stop": float(stop[i])}
    return events

def _metrics(t: pd.DataFrame, initial: float, equity: float, maxdd: float) -> dict:
    if len(t):
        wins = t.net_pnl > 0
        gross_win = float(t.loc[wins, "net_pnl"].sum())
        gross_loss = float(-t.loc[~wins, "net_pnl"].sum())
        pf = gross_win / gross_loss if gross_loss > 0 else None
        exp = float(t.r_net.mean())
        win = float(wins.mean() * 100)
    else:
        pf, exp, win = None, 0.0, 0.0
    return {"trades": int(len(t)), "profit_factor": pf, "expectancy_r": exp, "return_r": float(t.r_net.sum()) if len(t) else 0.0,
            "return_pct": float((equity / initial - 1) * 100), "max_drawdown_pct": float(maxdd * 100), "win_rate_pct": win}


def run_backtest(f: pd.DataFrame, spec: Spec, start: pd.Timestamp, end: pd.Timestamp,
                 fee: float = 0.0004, slip: float = 0.0001, entry_delay_bars: int = 0,
                 initial: float = 100_000.0, allowed_end: pd.Timestamp = PREHOLDOUT_END) -> tuple[pd.DataFrame, dict]:
    if end > allowed_end:
        raise ValueError("backtest end exceeds the explicitly authorized boundary")
    events = setup_events(f, spec)
    by_entry: dict[int, list[dict]] = {}
    for ev in events:
        entry_i = ev["complete_i"] + 1 + entry_delay_bars
        by_entry.setdefault(entry_i, []).append(ev)
    O, H, L, C, ATR = (f[c].to_numpy() for c in ("open", "high", "low", "close", "atr"))
    idx = f.index
    start_i, end_i = int(idx.searchsorted(start)), int(idx.searchsorted(end))
    equity, peak, maxdd = initial, initial, 0.0
    position = None
    cooldown_until = -1
    trades: list[dict] = []

    def close_position(pos: dict, i: int, reason: str, exit_px: float) -> None:
        nonlocal equity, peak, maxdd, cooldown_until
        side = pos["side"]
        gross = (exit_px - pos["entry"]) * pos["qty"] if side == "LONG" else (pos["entry"] - exit_px) * pos["qty"]
        fees = fee * (pos["entry"] + exit_px) * pos["qty"]
        net = gross - fees
        equity += net
        risk_cash = pos["risk_unit"] * pos["qty"]
        trades.append({"architecture": spec.architecture, "side": side, "signal_time": str(pos["signal_time"]),
                       "entry_time": str(pos["entry_time"]), "exit_time": str(idx[i]), "entry": pos["entry"], "exit": exit_px,
                       "qty": pos["qty"], "stop_initial": pos["stop_initial"], "target_initial": pos["target_initial"],
                       "exit_reason": reason, "bars_held": i - pos["entry_i"] + 1, "gross_pnl": gross, "fees": fees,
                       "net_pnl": net, "r_net": net / risk_cash if risk_cash else 0.0, "equity_after": equity,
                       "market_regime": pos["market_regime"], "vol_regime": pos["vol_regime"],
                       "h4_trend_score": pos["h4_trend_score"]})
        cooldown_until = i + spec.cooldown_bars
        peak = max(peak, equity)
        maxdd = min(maxdd, equity / peak - 1)

    def intrabar_exit(pos: dict, i: int, allow_max_hold: bool) -> tuple[str | None, float | None]:
        side, stop, target = pos["side"], pos["stop"], pos["target"]
        bars_held = i - pos["entry_i"] + 1
        # Time exits occur at the bar open, before using that bar's high/low.
        if allow_max_hold and bars_held >= spec.max_hold_bars:
            return "MAX_HOLD", adverse(O[i], side, "EXIT", slip)
        stop_hit = L[i] <= stop if side == "LONG" else H[i] >= stop
        target_hit = H[i] >= target if side == "LONG" else L[i] <= target
        if stop_hit or target_hit:
            reason = "STOP" if stop_hit else "TARGET"  # stop-first on ambiguous bars
            level = stop if reason == "STOP" else target
            return reason, trigger_fill(side, reason, O[i], level, slip)
        return None, None

    def update_trailing(pos: dict, i: int) -> None:
        side = pos["side"]
        if side == "LONG":
            pos["best"] = max(pos["best"], H[i]); fav = pos["best"] - pos["entry"]
        else:
            pos["best"] = min(pos["best"], L[i]); fav = pos["entry"] - pos["best"]
        r_mult = fav / max(pos["initial_distance"], 1e-12)
        next_stop = pos["stop"]
        if r_mult >= spec.breakeven_r:
            next_stop = max(next_stop, pos["entry"]) if side == "LONG" else min(next_stop, pos["entry"])
        if r_mult >= spec.trail_start_r and np.isfinite(ATR[i]):
            trail = pos["best"] - ATR[i] * spec.trail_atr_mult if side == "LONG" else pos["best"] + ATR[i] * spec.trail_atr_mult
            next_stop = max(next_stop, trail) if side == "LONG" else min(next_stop, trail)
        pos["stop"] = next_stop  # becomes active only on the following bar

    for i in range(max(1, start_i), min(end_i, len(f))):
        ts = idx[i]
        if position is not None:
            reason, exit_px = intrabar_exit(position, i, allow_max_hold=True)
            if reason is not None:
                close_position(position, i, reason, float(exit_px))
                position = None
            else:
                update_trailing(position, i)
            # Never close and re-enter on the same hourly candle.
            continue

        if i < cooldown_until or i not in by_entry:
            continue
        # Same-side architecture has at most one relevant completed setup; latest wins deterministically.
        ev = max(by_entry[i], key=lambda z: z["complete_i"])
        signal_i = ev["complete_i"]
        if signal_i < start_i or i >= end_i:
            continue
        side = spec.side
        entry = adverse(O[i], side, "ENTRY", slip)
        stop = float(ev["stop"])
        distance = entry - stop if side == "LONG" else stop - entry
        if not np.isfinite(distance) or distance <= 0 or distance > float(f.atr.iloc[signal_i]) * spec.atr_stop_cap * 1.15:
            continue
        stop_exit = trigger_fill(side, "STOP", stop, stop, slip)
        risk_unit = (entry - stop_exit if side == "LONG" else stop_exit - entry) + fee * (entry + stop_exit)
        budget = equity * spec.risk_pct * float(ev.get("risk_scale", 1.0))
        qty = min(budget / max(risk_unit, 1e-12), equity * spec.max_leverage / max(entry, 1e-12))
        if qty <= 0:
            continue
        target = entry + distance * spec.reward_risk if side == "LONG" else entry - distance * spec.reward_risk
        r = f.iloc[signal_i]
        position = {"side": side, "signal_time": idx[signal_i], "entry_time": ts, "entry_i": i, "entry": entry, "qty": qty,
                    "risk_unit": risk_unit, "initial_distance": distance, "stop": stop, "stop_initial": stop,
                    "target": target, "target_initial": target, "best": entry, "market_regime": str(r.market_regime),
                    "vol_regime": str(r.vol_regime), "h4_trend_score": float(r.h4_trend_score)}
        # Entry is at the bar open, therefore stop/target exposure begins on that same bar.
        reason, exit_px = intrabar_exit(position, i, allow_max_hold=False)
        if reason is not None:
            close_position(position, i, reason, float(exit_px))
            position = None
        else:
            update_trailing(position, i)

    # Do not silently discard unresolved exposure at the authorized boundary.
    if position is not None and min(end_i, len(f)) > 0:
        final_i = min(end_i, len(f)) - 1
        close_position(position, final_i, "END_OF_WINDOW", adverse(C[final_i], position["side"], "EXIT", slip))
        position = None

    t = pd.DataFrame(trades)
    return t, {**_metrics(t, initial, equity, maxdd), "spec": asdict(spec), "fee_per_side": fee,
               "slippage": slip, "entry_delay_bars": entry_delay_bars, "research_only": True, "android_integration_allowed": False}


def central_specs() -> list[Spec]:
    return [Spec(a, side) for a in ("BASE_DONCHIAN", "CONTINUOUS_REGIME", "BREAKOUT_CONFIRMATION", "BREAKOUT_RETEST") for side in ("LONG", "SHORT")]


def one_at_a_time_neighbours(spec: Spec) -> list[Spec]:
    candidates = [spec]
    for v in (20, 28): candidates.append(replace(spec, channel_bars=v))
    for v in (1.6, 2.0): candidates.append(replace(spec, atr_stop_mult=v))
    if spec.architecture == "CONTINUOUS_REGIME":
        for v in (0.25, 0.45): candidates.append(replace(spec, regime_threshold=v))
    elif spec.architecture == "BREAKOUT_CONFIRMATION":
        candidates.append(replace(spec, confirmation_bars=2))
    elif spec.architecture == "BREAKOUT_RETEST":
        for v in (2, 4): candidates.append(replace(spec, retest_window_bars=v))
    unique = {str(asdict(x)): x for x in candidates}
    return list(unique.values())
