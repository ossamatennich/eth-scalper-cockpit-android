#!/usr/bin/env python3
"""Nested annual/monthly validation of the pre-locked false-breakout families."""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from dataclasses import asdict
from pathlib import Path

import numpy as np
import pandas as pd

from v233_false_breakout_architectures import (
    PREHOLDOUT_END, Spec, central_specs, load_ohlcv, one_at_a_time_neighbours, prepare_features, run_backtest,
)

START = pd.Timestamp("2021-01-01T00:00:00Z")
MONTHLY_OUTER_START = pd.Timestamp("2022-01-01T00:00:00Z")
SEED = 23320260717


def pf(t: pd.DataFrame) -> float | None:
    if len(t) == 0:
        return None
    basis = "net_pnl" if "net_pnl" in t.columns else "r_net"
    win = t[basis] > 0
    gain, loss = float(t.loc[win, basis].sum()), float(-t.loc[~win, basis].sum())
    return gain / loss if loss > 0 else None


def trade_metrics(t: pd.DataFrame) -> dict:
    if len(t) == 0:
        return {"trades": 0, "profit_factor": None, "expectancy_r": 0.0, "return_r": 0.0, "win_rate_pct": 0.0,
                "max_drawdown_r": 0.0}
    r = t.r_net.astype(float).to_numpy()
    curve = np.cumsum(r)
    dd = curve - np.maximum.accumulate(np.r_[0.0, curve])[-len(curve):]
    return {"trades": int(len(t)), "profit_factor": pf(t), "expectancy_r": float(np.mean(r)), "return_r": float(np.sum(r)),
            "win_rate_pct": float(np.mean(r > 0) * 100), "max_drawdown_r": float(dd.min(initial=0.0))}


def ensure_times(t: pd.DataFrame) -> pd.DataFrame:
    z = t.copy()
    if len(z):
        z["entry_time"] = pd.to_datetime(z.entry_time, utc=True)
        z["exit_time"] = pd.to_datetime(z.exit_time, utc=True)
    return z


def slice_trades(t: pd.DataFrame, start: pd.Timestamp, end: pd.Timestamp) -> pd.DataFrame:
    if len(t) == 0:
        return t.copy()
    return t[(t.entry_time >= start) & (t.entry_time < end)].copy()


def monthly_table(t: pd.DataFrame, start: pd.Timestamp = START, end: pd.Timestamp = PREHOLDOUT_END) -> pd.DataFrame:
    rows = []
    for s in pd.date_range(start, end - pd.offsets.MonthBegin(1), freq="MS", tz="UTC"):
        e = s + pd.offsets.MonthBegin(1)
        rows.append({"month": s.strftime("%Y-%m"), **trade_metrics(slice_trades(t, s, min(e, end)))})
    return pd.DataFrame(rows)


def rolling_quarters(t: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for s in pd.date_range(pd.Timestamp("2021-01-01", tz="UTC"), PREHOLDOUT_END - pd.offsets.MonthBegin(3), freq="MS"):
        e = s + pd.offsets.MonthBegin(3)
        rows.append({"start": str(s), "end": str(e), **trade_metrics(slice_trades(t, s, e))})
    return pd.DataFrame(rows)


def selection_score_from_tables(train: pd.DataFrame, month: pd.DataFrame) -> float:
    active = month[month.trades > 0]
    met = trade_metrics(train)
    if met["trades"] < 12 or len(active) < 6:
        return -1e9 + met["trades"]
    p = float(met["profit_factor"] or 0)
    pos = float((active.expectancy_r > 0).mean())
    median = float(active.expectancy_r.median())
    worst = float(active.expectancy_r.quantile(0.10))
    return median + 0.12 * min(p, 2.5) + 0.20 * pos + 0.15 * worst


def _variant_cache(variants: list[tuple[Spec, pd.DataFrame]]) -> list[tuple[Spec, pd.DataFrame, pd.DataFrame]]:
    cache = []
    for spec, trades in variants:
        m = monthly_table(trades)
        m["month_start"] = pd.to_datetime(m.month + "-01", utc=True)
        cache.append((spec, trades, m))
    return cache

def nested_monthly(variants: list[tuple[Spec, pd.DataFrame]]) -> tuple[pd.DataFrame, pd.DataFrame]:
    folds, outer_parts = [], []
    cache = _variant_cache(variants)
    for s in pd.date_range(MONTHLY_OUTER_START, PREHOLDOUT_END - pd.offsets.MonthBegin(1), freq="MS", tz="UTC"):
        e = min(s + pd.offsets.MonthBegin(1), PREHOLDOUT_END)
        scored = []
        for spec, trades, month in cache:
            train = slice_trades(trades, START, s)
            train_month = month[month.month_start < s]
            scored.append((selection_score_from_tables(train, train_month), spec, trades, trade_metrics(train)))
        scored.sort(key=lambda z: (z[0], json.dumps(asdict(z[1]), sort_keys=True)), reverse=True)
        score, chosen, all_t, train_m = scored[0]
        outer = slice_trades(all_t, s, e)
        if len(outer):
            outer = outer.copy(); outer["outer_fold"] = s.strftime("%Y-%m"); outer["selected_spec"] = json.dumps(asdict(chosen), sort_keys=True)
            outer_parts.append(outer)
        folds.append({"fold": s.strftime("%Y-%m"), "train_end_exclusive": str(s), "selected_spec": asdict(chosen),
                      "selection_score": score, "train": train_m, "outer": trade_metrics(outer)})
    return (pd.concat(outer_parts, ignore_index=True) if outer_parts else pd.DataFrame(), pd.DataFrame(folds))


def nested_annual(variants: list[tuple[Spec, pd.DataFrame]]) -> pd.DataFrame:
    rows = []
    cache = _variant_cache(variants)
    for year in (2022, 2023, 2024, 2025, 2026):
        s = pd.Timestamp(f"{year}-01-01", tz="UTC")
        e = min(pd.Timestamp(f"{year+1}-01-01", tz="UTC"), PREHOLDOUT_END)
        scored = []
        for spec, trades, month in cache:
            train = slice_trades(trades, START, s)
            train_month = month[month.month_start < s]
            scored.append((selection_score_from_tables(train, train_month), spec, trades, trade_metrics(train)))
        scored.sort(key=lambda z: (z[0], json.dumps(asdict(z[1]), sort_keys=True)), reverse=True)
        score, chosen, all_t, train_m = scored[0]
        outer = slice_trades(all_t, s, e)
        rows.append({"fold": f"Y{year}", "start": str(s), "end_exclusive": str(e), "selected_spec": json.dumps(asdict(chosen), sort_keys=True),
                     "selection_score": score, **{f"outer_{k}": v for k, v in trade_metrics(outer).items()}})
    return pd.DataFrame(rows)

def bootstrap_iid(r: np.ndarray, n: int = 10_000, seed: int = SEED) -> dict:
    if len(r) == 0:
        return {"samples": n, "p_mean_positive": 0.0, "q10_mean_r": -math.inf}
    rng = np.random.default_rng(seed)
    means = r[rng.integers(0, len(r), size=(n, len(r)))].mean(axis=1)
    return {"samples": n, "p_mean_positive": float(np.mean(means > 0)), "q10_mean_r": float(np.quantile(means, 0.10)),
            "q05_mean_r": float(np.quantile(means, 0.05))}


def bootstrap_month_blocks(t: pd.DataFrame, n: int = 10_000, seed: int = SEED + 1) -> dict:
    if len(t) == 0:
        return {"samples": n, "p_mean_positive": 0.0, "q10_mean_r": -math.inf}
    z = t.copy(); z["month"] = z.entry_time.dt.tz_localize(None).dt.to_period("M").astype(str)
    grouped = z.groupby("month").r_net.agg(["sum", "count"])
    sums = grouped["sum"].to_numpy(float); counts = grouped["count"].to_numpy(float)
    if len(sums) == 0:
        return {"samples": n, "p_mean_positive": 0.0, "q10_mean_r": -math.inf}
    rng = np.random.default_rng(seed)
    picks = rng.integers(0, len(sums), size=(n, len(sums)))
    means = sums[picks].sum(axis=1) / np.maximum(counts[picks].sum(axis=1), 1.0)
    return {"samples": n, "p_mean_positive": float(np.mean(means > 0)), "q10_mean_r": float(np.quantile(means, 0.10))}


def monte_carlo_order(r: np.ndarray, risk_pct: float = 0.0015, n: int = 10_000, seed: int = SEED + 2) -> dict:
    if len(r) == 0:
        return {"samples": n, "q95_max_drawdown_abs": math.inf}
    rng = np.random.default_rng(seed)
    dds = np.empty(n)
    batch = 500
    for first in range(0, n, batch):
        size = min(batch, n - first)
        order = np.argsort(rng.random((size, len(r))), axis=1)
        rr = r[order]
        eq = np.cumprod(1 + risk_pct * rr, axis=1)
        peak = np.maximum.accumulate(np.concatenate([np.ones((size, 1)), eq], axis=1), axis=1)[:, 1:]
        dds[first:first+size] = np.abs(np.min(eq / peak - 1.0, axis=1))
    return {"samples": n, "q50_max_drawdown_abs": float(np.quantile(dds, 0.50)), "q95_max_drawdown_abs": float(np.quantile(dds, 0.95)),
            "q99_max_drawdown_abs": float(np.quantile(dds, 0.99))}

def regime_table(t: pd.DataFrame) -> pd.DataFrame:
    if len(t) == 0:
        return pd.DataFrame(columns=["market_regime", "vol_regime", "trades", "profit_factor", "expectancy_r", "return_r"])
    rows = []
    for (market, vol), g in t.groupby(["market_regime", "vol_regime"], dropna=False):
        rows.append({"market_regime": market, "vol_regime": vol, **trade_metrics(g)})
    return pd.DataFrame(rows).sort_values(["market_regime", "vol_regime"])


def criteria_checks(central_t: pd.DataFrame, central_m: dict, monthly: pd.DataFrame, quarters: pd.DataFrame,
                    nested_t: pd.DataFrame, annual: pd.DataFrame, stresses: dict, neighbour_rows: list[dict],
                    iid: dict, blocks: dict, mc: dict, regimes: pd.DataFrame, criteria: dict) -> dict:
    req = criteria["required_all"]
    active = monthly[monthly.trades > 0]
    active_ratio = float((active.expectancy_r > 0).mean()) if len(active) else 0.0
    active_median = float(active.expectancy_r.median()) if len(active) else -math.inf
    active_quarters = quarters[quarters.trades > 0]
    quarter_ratio = float((active_quarters.expectancy_r > 0).mean()) if len(active_quarters) else 0.0
    worst_quarter = float(active_quarters.expectancy_r.min()) if len(active_quarters) else -math.inf
    annual_active = annual[annual.outer_trades > 0]
    annual_ratio = float((annual_active.outer_expectancy_r > 0).mean()) if len(annual_active) else 0.0
    pass_neighbours = [r for r in neighbour_rows if r["passes_basic"]]
    neighbour_fraction = len(pass_neighbours) / max(len(neighbour_rows), 1)
    total_abs = float(central_t.r_net.abs().sum()) if len(central_t) else 0.0
    single_fraction = float(central_t.r_net.abs().max() / total_abs) if total_abs else math.inf
    profitable = regimes[regimes.expectancy_r > 0]
    positive_sum = float(profitable.return_r.clip(lower=0).sum()) if len(profitable) else 0.0
    largest_regime_fraction = float(profitable.return_r.clip(lower=0).max() / positive_sum) if positive_sum > 0 else math.inf
    stress_cost = [stresses[k] for k in ("FEES_X1_5", "SLIPPAGE_X2", "FEES_X1_5_SLIPPAGE_X2")]
    checks = {
        "nested_outer_trades": trade_metrics(nested_t)["trades"] >= req["nested_outer_trades_min"],
        "active_months": len(active) >= req["active_months_min"],
        "positive_active_month_ratio": active_ratio >= req["positive_active_month_ratio_min"],
        "positive_rolling_quarter_ratio": quarter_ratio >= req["positive_rolling_quarter_ratio_min"],
        "positive_annual_outer_ratio": len(annual_active) >= req["annual_outer_folds_min"] and annual_ratio >= req["positive_annual_outer_ratio_min"],
        "median_active_month_expectancy": active_median >= req["median_active_month_expectancy_r_min"],
        "worst_rolling_quarter_expectancy": worst_quarter >= req["worst_rolling_quarter_expectancy_r_min"],
        "base_profit_factor": float(central_m["profit_factor"] or 0) >= req["base_profit_factor_min"],
        "base_expectancy": central_m["expectancy_r"] >= req["base_expectancy_r_min"],
        "cost_stress_profit_factor": all(float(x["profit_factor"] or 0) >= req["cost_stress_profit_factor_min"] for x in stress_cost),
        "entry_delay_1_profit_factor": float(stresses["ENTRY_DELAY_1H"]["profit_factor"] or 0) >= req["entry_delay_1_profit_factor_min"],
        "entry_delay_2_expectancy": stresses["ENTRY_DELAY_2H"]["expectancy_r"] >= req["entry_delay_2_expectancy_r_min"],
        "iid_bootstrap_q10": iid["q10_mean_r"] >= req["iid_bootstrap_10pct_expectancy_r_min"],
        "month_block_bootstrap": blocks["p_mean_positive"] >= req["month_block_bootstrap_probability_mean_positive_min"],
        "monte_carlo_drawdown": mc["q95_max_drawdown_abs"] <= req["monte_carlo_95pct_max_drawdown_abs_max"],
        "parameter_neighbours": neighbour_fraction >= req["parameter_neighbour_pass_fraction_min"],
        "single_trade_contribution": single_fraction <= req["single_trade_absolute_contribution_max_fraction"],
        "profitable_regime_buckets": len(profitable) >= req["profitable_regime_buckets_min"],
        "regime_concentration": largest_regime_fraction <= req["largest_positive_regime_contribution_max_fraction"],
    }
    diagnostics = {"active_months": len(active), "positive_active_month_ratio": active_ratio,
                   "positive_rolling_quarter_ratio": quarter_ratio, "worst_rolling_quarter_expectancy_r": worst_quarter,
                   "positive_annual_outer_ratio": annual_ratio, "annual_outer_active_folds": len(annual_active),
                   "parameter_neighbour_pass_fraction": neighbour_fraction, "single_trade_absolute_contribution_fraction": single_fraction,
                   "profitable_regime_buckets": len(profitable), "largest_positive_regime_contribution_fraction": largest_regime_fraction,
                   "failed_checks": [k for k, v in checks.items() if not v]}
    return {"passes_all": all(checks.values()), "checks": checks, "diagnostics": diagnostics}


def verify_lock(path: Path) -> str:
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    sha_path = path.with_suffix(".sha256")
    expected = sha_path.read_text().strip().split()[0]
    if digest != expected:
        raise ValueError(f"Lock hash mismatch for {path}")
    return digest


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("corpus", type=Path)
    ap.add_argument("--output", type=Path, default=Path("results/historical"))
    ap.add_argument("--protocol-dir", type=Path, default=Path("protocol"))
    ap.add_argument("--corpus-audit", type=Path, default=None)
    args = ap.parse_args()
    out = args.output; out.mkdir(parents=True, exist_ok=True)
    arch_hash = verify_lock(args.protocol_dir / "LOCKED_ARCHITECTURES_V2.json")
    criteria_path = args.protocol_dir / "LOCKED_CRITERIA_V2.json"
    criteria_hash = verify_lock(criteria_path)
    criteria = json.loads(criteria_path.read_text())
    raw = load_ohlcv(args.corpus)
    if len(raw) != 47_448 or raw.index.min() != START or raw.index.max() != PREHOLDOUT_END - pd.Timedelta(hours=1):
        raise ValueError(f"Extended corpus coverage mismatch: rows={len(raw)}, min={raw.index.min()}, max={raw.index.max()}")
    features = prepare_features(raw)
    candidate_reports = []
    for central in central_specs():
        family_dir = out / f"{central.architecture}__{central.side}"; family_dir.mkdir(exist_ok=True)
        variants = []
        neighbour_rows = []
        for j, spec in enumerate(one_at_a_time_neighbours(central)):
            t, m = run_backtest(features, spec, START, PREHOLDOUT_END)
            t = ensure_times(t)
            variants.append((spec, t))
            basic = bool(m["trades"] >= 50 and float(m["profit_factor"] or 0) >= 1.10 and m["expectancy_r"] > 0)
            neighbour_rows.append({"variant": j, "spec": asdict(spec), **{k: m[k] for k in ("trades", "profit_factor", "expectancy_r", "return_r", "max_drawdown_pct")}, "passes_basic": basic})
        central_t = variants[0][1]
        central_m = trade_metrics(central_t)
        month = monthly_table(central_t); quarter = rolling_quarters(central_t)
        nested_t, nested_folds = nested_monthly(variants)
        nested_t = ensure_times(nested_t)
        annual = nested_annual(variants)
        stresses = {}
        for label, fee, slip, delay in (("BASE", .0004, .0001, 0), ("FEES_X1_5", .0006, .0001, 0), ("SLIPPAGE_X2", .0004, .0002, 0),
                                         ("FEES_X1_5_SLIPPAGE_X2", .0006, .0002, 0), ("ENTRY_DELAY_1H", .0004, .0001, 1), ("ENTRY_DELAY_2H", .0004, .0001, 2)):
            _, sm = run_backtest(features, central, START, PREHOLDOUT_END, fee=fee, slip=slip, entry_delay_bars=delay)
            stresses[label] = {k: sm[k] for k in ("trades", "profit_factor", "expectancy_r", "return_r", "return_pct", "max_drawdown_pct")}
        r = central_t.r_net.to_numpy(float) if len(central_t) else np.array([])
        iid, blocks, mc = bootstrap_iid(r), bootstrap_month_blocks(central_t), monte_carlo_order(r)
        regimes = regime_table(central_t)
        gate = criteria_checks(central_t, central_m, month, quarter, nested_t, annual, stresses, neighbour_rows, iid, blocks, mc, regimes, criteria)
        central_t.to_csv(family_dir / "central_trades.csv", index=False)
        nested_t.to_csv(family_dir / "nested_outer_trades.csv", index=False)
        nested_folds.to_json(family_dir / "nested_monthly_folds.json", orient="records", indent=2)
        annual.to_csv(family_dir / "nested_annual_folds.csv", index=False)
        month.to_csv(family_dir / "central_months.csv", index=False)
        quarter.to_csv(family_dir / "central_rolling_quarters.csv", index=False)
        regimes.to_csv(family_dir / "central_regimes.csv", index=False)
        pd.DataFrame(neighbour_rows).to_json(family_dir / "neighbours.json", orient="records", indent=2)
        report = {"central_spec": asdict(central), "central": central_m, "nested_monthly": trade_metrics(nested_t),
                  "nested_annual": annual.to_dict(orient="records"), "stress": stresses, "iid_bootstrap": iid,
                  "month_block_bootstrap": blocks, "monte_carlo": mc, "gate": gate}
        (family_dir / "REPORT.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
        candidate_reports.append({"architecture": central.architecture, "side": central.side, "passes_all": gate["passes_all"],
                                  "central": central_m, "nested_monthly": trade_metrics(nested_t), "failed_checks": gate["diagnostics"]["failed_checks"],
                                  "path": str(family_dir / "REPORT.json")})
    admitted = [x for x in candidate_reports if x["passes_all"]]
    corpus_audit = json.loads(args.corpus_audit.read_text()) if args.corpus_audit else None
    corpus_passed = corpus_audit is None or corpus_audit.get("status") == "PASS"
    authorized = corpus_passed and len(admitted) == 1
    authorization = {"authorized": authorized, "candidate_count": len(admitted), "candidate": admitted[0] if len(admitted) == 1 else None,
                     "reason": ("EXACTLY_ONE_PREHOLDOUT_CANDIDATE_PASSED" if authorized
                                else ("CORPUS_AUDIT_FAILED_HOLDOUT_REMAINS_SEALED" if not corpus_passed else "HOLDOUT_REMAINS_SEALED")),
                     "no_parameter_change_after_authorization": True}
    (out / "HOLDOUT_OPEN_AUTHORIZATION.json").write_text(json.dumps(authorization, indent=2), encoding="utf-8")
    corpus_criteria_failed = corpus_audit.get("criteria", {}).get("failed", []) if corpus_audit else []
    corpus_criteria_passed = corpus_audit.get("criteria", {}).get("passed", []) if corpus_audit else []
    strategy_failed = sorted({f"strategy_{r['architecture']}__{r['side']}__{x}" for r in candidate_reports for x in r["failed_checks"]})
    strategy_passed = [f"strategy_{r['architecture']}__{r['side']}__all_required_gates" for r in candidate_reports if r["passes_all"]]
    controlled = None
    periods_loaded = None
    if corpus_audit:
        one_rows = int(corpus_audit["one_hour"]["rows"])
        four_rows = int(corpus_audit["four_hour_native"]["rows"])
        controlled = {"one_hour": one_rows, "four_hour_native": four_rows, "total": one_rows + four_rows}
        periods_loaded = sorted({x["period"] for x in corpus_audit.get("archive_manifest", [])})
    decision = {"research_only": True, "android_integration_allowed": False, "stable": False,
                "holdout_opened": False, "holdout_start": str(PREHOLDOUT_END),
                "controlled_candles": controlled,
                "loaded_periods": periods_loaded,
                "criteria_passed": corpus_criteria_passed + strategy_passed,
                "criteria_failed": corpus_criteria_failed + strategy_failed,
                "corpus_audit_status": corpus_audit.get("status") if corpus_audit else "NOT_PROVIDED",
                "corpus_crosscheck": corpus_audit.get("four_hour_crosscheck") if corpus_audit else None,
                "protocol_hashes": {"architectures": arch_hash, "criteria": criteria_hash},
                "candidate_reports": candidate_reports, "preholdout_admissible_count": len(admitted),
                "decision": "AUTHORIZED_FOR_SINGLE_HOLDOUT_OPEN" if authorized else "KEEP_HOLDOUT_CLOSED"}
    (out / "PREHOLDOUT_STRICT_DECISION.json").write_text(json.dumps(decision, indent=2), encoding="utf-8")
    pd.DataFrame(candidate_reports).to_json(out / "CANDIDATE_SUMMARY.json", orient="records", indent=2)
    print(json.dumps(decision, indent=2))


if __name__ == "__main__":
    main()
