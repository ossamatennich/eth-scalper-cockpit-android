#!/usr/bin/env python3
"""Open the sealed holdout exactly once, only after a single pre-holdout authorization.

This script is intentionally separate from the pre-holdout research job.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import pandas as pd

from binance_historical_extension import (
    COLS, compare_4h, derive_4h, deterministic_null_repair, fetch_bytes, normalize,
    parse_checksum, read_archive, validate_ohlcv,
)
from v233_false_breakout_architectures import Spec, load_ohlcv, prepare_features, run_backtest

HOLDOUT_START = pd.Timestamp("2026-06-01T00:00:00Z")
HOLDOUT_END = pd.Timestamp("2026-07-17T00:00:00Z")
EXPECTED_1H = 1104
EXPECTED_4H = 276
BASE = "https://data.binance.vision/data/futures/um"


def sources(interval: str) -> list[tuple[str, str]]:
    items = []
    monthly = f"ETHUSDT-{interval}-2026-06.zip"
    items.append((monthly, f"{BASE}/monthly/klines/ETHUSDT/{interval}/{monthly}"))
    for day in range(1, 17):
        name = f"ETHUSDT-{interval}-2026-07-{day:02d}.zip"
        items.append((name, f"{BASE}/daily/klines/ETHUSDT/{interval}/{name}"))
    return items


def download_holdout(raw_dir: Path) -> tuple[dict[str, pd.DataFrame], list[dict]]:
    frames, manifest = {}, []
    for interval, freq in (("1h", "1h"), ("4h", "4h")):
        pieces = []
        d = raw_dir / interval; d.mkdir(parents=True, exist_ok=True)
        for name, url in sources(interval):
            payload, retries = fetch_bytes(url)
            checksum, _ = fetch_bytes(url + ".CHECKSUM")
            expected = parse_checksum(checksum.decode("utf-8", errors="replace"), name)
            actual = hashlib.sha256(payload).hexdigest()
            if expected != actual:
                raise ValueError(f"Checksum mismatch: {name}")
            (d / name).write_bytes(payload)
            z = normalize(read_archive(payload)); pieces.append(z)
            manifest.append({"interval": interval, "file": name, "url": url, "sha256": actual,
                             "checksum_verified": True, "rows_raw": len(z), "retries": retries})
        x = pd.concat(pieces).sort_index()
        if x.index.duplicated().any():
            conflicts = [str(ts) for ts, g in x[x.index.duplicated(keep=False)].groupby(level=0) if len(g.drop_duplicates()) > 1]
            if conflicts:
                raise ValueError(f"Conflicting duplicates: {conflicts[:10]}")
            x = x[~x.index.duplicated(keep="first")]
        x = x[(x.index >= HOLDOUT_START) & (x.index < HOLDOUT_END)]
        x, repairs = deterministic_null_repair(x, freq)
        frames[interval] = x
        manifest.append({"interval": interval, "deterministic_null_repairs": repairs})
    return frames, manifest


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--authorization", type=Path, required=True)
    ap.add_argument("--preholdout-corpus", type=Path, required=True)
    ap.add_argument("--output", type=Path, default=Path("results/holdout"))
    ap.add_argument("--marker", type=Path, default=Path(".holdout_once/OPENED.json"))
    args = ap.parse_args()
    auth = json.loads(args.authorization.read_text())
    if not auth.get("authorized") or auth.get("candidate_count") != 1:
        raise SystemExit("Holdout opening refused: exactly one authorized candidate is required")
    if args.marker.exists():
        raise SystemExit("Holdout opening refused: persistent one-time marker already exists")
    candidate = auth["candidate"]
    central = Spec(candidate["architecture"], candidate["side"])
    out = args.output; out.mkdir(parents=True, exist_ok=True)
    frames, manifest = download_holdout(out / "raw")
    a1 = validate_ohlcv(frames["1h"], HOLDOUT_START, HOLDOUT_END, "1h")
    a4 = validate_ohlcv(frames["4h"], HOLDOUT_START, HOLDOUT_END, "4h")
    cross = compare_4h(frames["4h"], derive_4h(frames["1h"]))
    if not (a1["rows"] == EXPECTED_1H and a4["rows"] == EXPECTED_4H and a1["missing_count"] == a4["missing_count"] == 0
            and a1["invalid_ohlcv_count"] == a4["invalid_ohlcv_count"] == 0
            and cross["price_mismatch_rows"] == cross["volume_mismatch_rows"] == 0):
        raise ValueError("Holdout corpus audit failed")
    pre = load_ohlcv(args.preholdout_corpus)
    combined = pd.concat([pre, frames["1h"]]).sort_index()
    if combined.index.duplicated().any():
        raise ValueError("Duplicate timestamp at preholdout/holdout boundary")
    features = prepare_features(combined)
    trades, metrics = run_backtest(features, central, HOLDOUT_START, HOLDOUT_END, allowed_end=HOLDOUT_END)
    gate = {"trades": metrics["trades"] >= 5, "profit_factor": float(metrics["profit_factor"] or 0) >= 1.10,
            "expectancy": metrics["expectancy_r"] >= 0.0, "max_drawdown": abs(metrics["max_drawdown_pct"] / 100) <= 0.02}
    stable = all(gate.values())
    trades.to_csv(out / "HOLDOUT_TRADES.csv", index=False)
    audit = {"status": "PASS", "start": str(HOLDOUT_START), "end_exclusive": str(HOLDOUT_END), "one_hour": a1,
             "four_hour": a4, "crosscheck": cross, "archive_manifest": manifest}
    (out / "HOLDOUT_CORPUS_AUDIT.json").write_text(json.dumps(audit, indent=2), encoding="utf-8")
    decision = {"research_only": True, "stable": stable, "android_integration_allowed": False,
                "holdout_opened": True, "holdout_open_count_this_protocol": 1, "candidate": candidate,
                "holdout_metrics": metrics, "holdout_gate": gate,
                "decision": "STABLE_RESEARCH_CANDIDATE_ANDROID_REVIEW_STILL_REQUIRED" if stable else "CANDIDATE_REJECTED_HOLDOUT_FAILED"}
    (out / "FINAL_STRICT_DECISION.json").write_text(json.dumps(decision, indent=2), encoding="utf-8")
    args.marker.parent.mkdir(parents=True, exist_ok=True)
    args.marker.write_text(json.dumps({"opened_at_protocol": "V233_HISTORICAL_GATE_2.0_LOCKED", "candidate": candidate,
                                      "decision_sha256": hashlib.sha256((out / "FINAL_STRICT_DECISION.json").read_bytes()).hexdigest()}, indent=2), encoding="utf-8")
    print(json.dumps(decision, indent=2))


if __name__ == "__main__":
    main()
