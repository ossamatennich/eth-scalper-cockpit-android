#!/usr/bin/env python3
"""Build the locked ETHUSDT USD-M Futures corpus from official Binance Vision archives.

Pre-holdout job only: 2021-01-01 <= timestamp < 2026-06-01.
The sealed 2026-06-01..2026-07-17 interval is never requested or loaded here.
Every archive is verified against its sibling .CHECKSUM before parsing.
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import time
import urllib.request
import zipfile
from dataclasses import dataclass, asdict
from pathlib import Path

import numpy as np
import pandas as pd

START = pd.Timestamp("2021-01-01T00:00:00Z")
PREHOLDOUT_END = pd.Timestamp("2026-06-01T00:00:00Z")
SEALED_END = pd.Timestamp("2026-07-17T00:00:00Z")
EXPECTED_1H = 47_448
EXPECTED_4H = 11_862
BASE = "https://data.binance.vision/data/futures/um/monthly/klines/ETHUSDT"
COLS = ["open_time", "open", "high", "low", "close", "volume", "close_time", "quote_volume", "trades", "taker_base", "taker_quote", "ignore"]


@dataclass
class ArchiveRecord:
    interval: str
    period: str
    url: str
    file: str
    bytes: int
    sha256: str
    checksum_verified: bool
    rows_raw: int
    retries: int


def month_starts() -> list[pd.Timestamp]:
    return list(pd.date_range(START, PREHOLDOUT_END - pd.offsets.MonthBegin(1), freq="MS", tz="UTC"))


def archive_url(interval: str, month: pd.Timestamp) -> str:
    stamp = month.strftime("%Y-%m")
    return f"{BASE}/{interval}/ETHUSDT-{interval}-{stamp}.zip"


def parse_checksum(text: str, filename: str) -> str:
    for line in text.replace("\r", "").splitlines():
        parts = line.strip().split()
        if not parts:
            continue
        digest = parts[0].lower()
        named = parts[-1].lstrip("*") if len(parts) > 1 else filename
        if named == filename and len(digest) == 64 and all(c in "0123456789abcdef" for c in digest):
            return digest
    raise ValueError(f"Valid checksum not found for {filename}")


def fetch_bytes(url: str, retries: int = 4, timeout: int = 60) -> tuple[bytes, int]:
    last: Exception | None = None
    for attempt in range(retries + 1):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "ETH-V233-research/2.0"})
            with urllib.request.urlopen(req, timeout=timeout) as response:
                return response.read(), attempt
        except Exception as exc:  # network errors are fatal after bounded retries
            last = exc
            if attempt < retries:
                time.sleep(min(2**attempt, 8))
    raise RuntimeError(f"Download failed after {retries + 1} attempts: {url}: {last}")


def read_archive(payload: bytes) -> pd.DataFrame:
    with zipfile.ZipFile(io.BytesIO(payload)) as zf:
        members = [n for n in zf.namelist() if not n.endswith("/")]
        if len(members) != 1:
            raise ValueError(f"Expected one CSV member, got {members}")
        raw = zf.read(members[0])
    # Binance archives may include a header in some generations.
    first = raw.splitlines()[0].decode("utf-8", errors="replace").lower()
    header = 0 if "open_time" in first or first.startswith("open time") else None
    df = pd.read_csv(io.BytesIO(raw), header=header)
    if df.shape[1] < 6:
        raise ValueError("Archive has fewer than six kline columns")
    df = df.iloc[:, : min(df.shape[1], 12)].copy()
    df.columns = COLS[: df.shape[1]]
    return df


def normalize(df: pd.DataFrame) -> pd.DataFrame:
    out = df[["open_time", "open", "high", "low", "close", "volume"]].copy()
    for c in ("open_time", "open", "high", "low", "close", "volume"):
        out[c] = pd.to_numeric(out[c], errors="coerce")
    if out.open_time.dropna().empty:
        raise ValueError("No timestamps")
    median = float(out.open_time.dropna().median())
    # Futures archives are milliseconds; tolerate a future microsecond migration.
    unit = "us" if median > 1e14 else "ms"
    out["timestamp"] = pd.to_datetime(out.open_time, unit=unit, utc=True, errors="coerce")
    out = out.drop(columns="open_time").set_index("timestamp").sort_index()
    return out


def deterministic_null_repair(df: pd.DataFrame, freq: str) -> tuple[pd.DataFrame, list[dict]]:
    """Repair only an objectively reconstructable null candle; otherwise fail.

    Allowed repair:
    - exactly one missing timestamp or one all-zero/NaN OHLC row;
    - previous close and next open differ by at most 1e-8 relative;
    - replacement is a flat zero-volume candle at that common boundary price.
    This never interpolates a price move and every repair is recorded.
    """
    x = df.copy().sort_index()
    full = pd.date_range(x.index.min(), x.index.max(), freq=freq, tz="UTC")
    x = x.reindex(full)
    repairs: list[dict] = []
    bad_ohlc = x[["open", "high", "low", "close"]].isna().all(axis=1) | (x[["open", "high", "low", "close"]].fillna(0) == 0).all(axis=1)
    candidates = np.flatnonzero(bad_ohlc.to_numpy())
    for i in candidates:
        ts = x.index[i]
        if i == 0 or i == len(x) - 1:
            raise ValueError(f"Null boundary candle cannot be repaired: {ts}")
        prev_close = x.iloc[i - 1].close
        next_open = x.iloc[i + 1].open
        if not np.isfinite(prev_close) or not np.isfinite(next_open):
            raise ValueError(f"Adjacent data unavailable for null candle: {ts}")
        rel = abs(float(prev_close) - float(next_open)) / max(abs(float(prev_close)), 1.0)
        if rel > 1e-8:
            raise ValueError(f"Null candle is not uniquely reconstructable at {ts}; boundary mismatch={rel}")
        px = (float(prev_close) + float(next_open)) / 2.0
        x.loc[ts, ["open", "high", "low", "close", "volume"]] = [px, px, px, px, 0.0]
        repairs.append({"timestamp": str(ts), "price": px, "method": "BOUNDARY_FLAT_ZERO_VOLUME", "boundary_relative_difference": rel})
    # Partial NaNs or partial zero OHLC are never guessed.
    partial_bad = x[["open", "high", "low", "close", "volume"]].isna().any(axis=1)
    partial_zero = (x[["open", "high", "low", "close"]] <= 0).any(axis=1)
    if partial_bad.any() or partial_zero.any():
        stamps = list(map(str, x.index[partial_bad | partial_zero][:10]))
        raise ValueError(f"Unrepairable OHLCV rows: {stamps}")
    x.index.name = "timestamp"
    return x, repairs


def validate_ohlcv(df: pd.DataFrame, start: pd.Timestamp, end: pd.Timestamp, freq: str) -> dict:
    expected = pd.date_range(start, end, freq=freq, inclusive="left", tz="UTC")
    missing = expected.difference(df.index)
    extra = df.index.difference(expected)
    dup = int(df.index.duplicated().sum())
    invalid = (
        (df[["open", "high", "low", "close"]] <= 0).any(axis=1)
        | (df.volume < 0)
        | (df.high < df[["open", "close"]].max(axis=1))
        | (df.low > df[["open", "close"]].min(axis=1))
        | (df.high < df.low)
    )
    return {
        "rows": int(len(df)),
        "expected_rows": int(len(expected)),
        "start": str(df.index.min()) if len(df) else None,
        "end": str(df.index.max()) if len(df) else None,
        "duplicates": dup,
        "missing_count": int(len(missing)),
        "extra_count": int(len(extra)),
        "invalid_ohlcv_count": int(invalid.sum()),
        "zero_volume_count": int((df.volume == 0).sum()),
        "missing_sample": list(map(str, missing[:10])),
        "extra_sample": list(map(str, extra[:10])),
    }


def derive_4h(one_h: pd.DataFrame) -> pd.DataFrame:
    return one_h.resample("4h", label="left", closed="left", origin="epoch").agg(
        open=("open", "first"), high=("high", "max"), low=("low", "min"), close=("close", "last"), volume=("volume", "sum")
    )


def compare_4h(native: pd.DataFrame, derived: pd.DataFrame) -> dict:
    common = native.index.intersection(derived.index)
    a = native.loc[common, ["open", "high", "low", "close", "volume"]]
    b = derived.loc[common, ["open", "high", "low", "close", "volume"]]
    diff = (a - b).abs()
    price_mismatch = (diff[["open", "high", "low", "close"]] > 1e-8).any(axis=1)
    volume_tol = np.maximum(a.volume.abs(), b.volume.abs()) * 1e-10 + 1e-8
    volume_mismatch = diff.volume > volume_tol
    mismatches = []
    mismatch_index = common[price_mismatch | volume_mismatch]
    for ts in mismatch_index[:20]:
        row = {
            "timestamp": str(ts),
            "native": {c: float(a.loc[ts, c]) for c in a.columns},
            "derived_from_1h": {c: float(b.loc[ts, c]) for c in b.columns},
            "absolute_difference": {c: float(diff.loc[ts, c]) for c in diff.columns},
            "price_mismatch": bool(price_mismatch.loc[ts]),
            "volume_mismatch": bool(volume_mismatch.loc[ts]),
        }
        mismatches.append(row)
    return {
        "rows_compared": int(len(common)),
        "price_mismatch_rows": int(price_mismatch.sum()),
        "volume_mismatch_rows": int(volume_mismatch.sum()),
        "max_abs_price_difference": float(diff[["open", "high", "low", "close"]].max().max()) if len(diff) else None,
        "max_abs_volume_difference": float(diff.volume.max()) if len(diff) else None,
        "mismatch_sample": mismatches,
    }


def build(output: Path, raw_dir: Path) -> dict:
    output.mkdir(parents=True, exist_ok=True)
    raw_dir.mkdir(parents=True, exist_ok=True)
    archive_records: list[ArchiveRecord] = []
    datasets: dict[str, pd.DataFrame] = {}
    repairs: dict[str, list[dict]] = {}
    for interval, freq in (("1h", "1h"), ("4h", "4h")):
        pieces = []
        interval_dir = raw_dir / interval
        interval_dir.mkdir(parents=True, exist_ok=True)
        for month in month_starts():
            stamp = month.strftime("%Y-%m")
            filename = f"ETHUSDT-{interval}-{stamp}.zip"
            url = archive_url(interval, month)
            payload, retries = fetch_bytes(url)
            checksum_payload, _ = fetch_bytes(url + ".CHECKSUM")
            expected_sha = parse_checksum(checksum_payload.decode("utf-8", errors="replace"), filename)
            actual_sha = hashlib.sha256(payload).hexdigest()
            if actual_sha != expected_sha:
                raise ValueError(f"Checksum mismatch: {filename}: expected {expected_sha}, got {actual_sha}")
            local = interval_dir / filename
            local.write_bytes(payload)
            frame = normalize(read_archive(payload))
            pieces.append(frame)
            archive_records.append(ArchiveRecord(interval, stamp, url, str(local.relative_to(output.parent)), len(payload), actual_sha, True, len(frame), retries))
        combined = pd.concat(pieces).sort_index()
        # Exact duplicates are harmless archive overlaps; conflicts are fatal.
        if combined.index.duplicated().any():
            groups = combined[combined.index.duplicated(keep=False)].groupby(level=0)
            conflicts = [str(ts) for ts, g in groups if len(g.drop_duplicates()) > 1]
            if conflicts:
                raise ValueError(f"Conflicting duplicate candles: {conflicts[:10]}")
            combined = combined[~combined.index.duplicated(keep="first")]
        combined = combined[(combined.index >= START) & (combined.index < PREHOLDOUT_END)]
        combined, fixed = deterministic_null_repair(combined, freq)
        datasets[interval] = combined
        repairs[interval] = fixed

    audit_1h = validate_ohlcv(datasets["1h"], START, PREHOLDOUT_END, "1h")
    audit_4h = validate_ohlcv(datasets["4h"], START, PREHOLDOUT_END, "4h")
    derived = derive_4h(datasets["1h"])
    cross = compare_4h(datasets["4h"], derived)
    pass_checks = (
        audit_1h["rows"] == EXPECTED_1H
        and audit_4h["rows"] == EXPECTED_4H
        and audit_1h["missing_count"] == audit_4h["missing_count"] == 0
        and audit_1h["extra_count"] == audit_4h["extra_count"] == 0
        and audit_1h["duplicates"] == audit_4h["duplicates"] == 0
        and audit_1h["invalid_ohlcv_count"] == audit_4h["invalid_ohlcv_count"] == 0
        and cross["price_mismatch_rows"] == cross["volume_mismatch_rows"] == 0
        and datasets["1h"].index.max() < PREHOLDOUT_END
    )
    audit = {
        "status": "PASS" if pass_checks else "FAIL",
        "research_only": True,
        "android_integration_allowed": False,
        "symbol": "ETHUSDT",
        "market": "Binance USD-M Futures",
        "source": "official monthly Binance Vision archives",
        "start": str(START),
        "end_exclusive": str(PREHOLDOUT_END),
        "sealed_holdout_not_requested": {"start": str(PREHOLDOUT_END), "end_exclusive": str(SEALED_END)},
        "archive_count": len(archive_records),
        "archive_manifest": [asdict(x) for x in archive_records],
        "one_hour": audit_1h,
        "four_hour_native": audit_4h,
        "four_hour_crosscheck": cross,
        "deterministic_null_repairs": repairs,
        "criteria": {
            "passed": [
                name for name, ok in {
                    "archive_checksums_verified": all(x.checksum_verified for x in archive_records),
                    "archive_count_130": len(archive_records) == 130,
                    "one_hour_expected_rows": audit_1h["rows"] == EXPECTED_1H,
                    "four_hour_expected_rows": audit_4h["rows"] == EXPECTED_4H,
                    "one_hour_no_missing": audit_1h["missing_count"] == 0,
                    "four_hour_no_missing": audit_4h["missing_count"] == 0,
                    "one_hour_no_extra": audit_1h["extra_count"] == 0,
                    "four_hour_no_extra": audit_4h["extra_count"] == 0,
                    "one_hour_no_duplicates": audit_1h["duplicates"] == 0,
                    "four_hour_no_duplicates": audit_4h["duplicates"] == 0,
                    "one_hour_valid_ohlcv": audit_1h["invalid_ohlcv_count"] == 0,
                    "four_hour_valid_ohlcv": audit_4h["invalid_ohlcv_count"] == 0,
                    "native_4h_matches_derived_1h_prices": cross["price_mismatch_rows"] == 0,
                    "native_4h_matches_derived_1h_volume": cross["volume_mismatch_rows"] == 0,
                    "holdout_period_not_loaded": datasets["1h"].index.max() < PREHOLDOUT_END,
                }.items() if ok
            ],
            "failed": [
                name for name, ok in {
                    "archive_checksums_verified": all(x.checksum_verified for x in archive_records),
                    "archive_count_130": len(archive_records) == 130,
                    "one_hour_expected_rows": audit_1h["rows"] == EXPECTED_1H,
                    "four_hour_expected_rows": audit_4h["rows"] == EXPECTED_4H,
                    "one_hour_no_missing": audit_1h["missing_count"] == 0,
                    "four_hour_no_missing": audit_4h["missing_count"] == 0,
                    "one_hour_no_extra": audit_1h["extra_count"] == 0,
                    "four_hour_no_extra": audit_4h["extra_count"] == 0,
                    "one_hour_no_duplicates": audit_1h["duplicates"] == 0,
                    "four_hour_no_duplicates": audit_4h["duplicates"] == 0,
                    "one_hour_valid_ohlcv": audit_1h["invalid_ohlcv_count"] == 0,
                    "four_hour_valid_ohlcv": audit_4h["invalid_ohlcv_count"] == 0,
                    "native_4h_matches_derived_1h_prices": cross["price_mismatch_rows"] == 0,
                    "native_4h_matches_derived_1h_volume": cross["volume_mismatch_rows"] == 0,
                    "holdout_period_not_loaded": datasets["1h"].index.max() < PREHOLDOUT_END,
                }.items() if not ok
            ],
        },
    }
    datasets["1h"].reset_index().to_csv(output / "ETHUSDT_UM_1h_2021-01-01_2026-05-31.csv.gz", index=False, compression="gzip")
    datasets["4h"].reset_index().to_csv(output / "ETHUSDT_UM_4h_native_2021-01-01_2026-05-31.csv.gz", index=False, compression="gzip")
    derived.reset_index().to_csv(output / "ETHUSDT_UM_4h_derived_2021-01-01_2026-05-31.csv.gz", index=False, compression="gzip")
    (output / "EXTENDED_CORPUS_AUDIT.json").write_text(json.dumps(audit, indent=2), encoding="utf-8")
    return audit


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=Path("data/extended"))
    parser.add_argument("--raw-dir", type=Path, default=Path("data/extended/raw"))
    args = parser.parse_args()
    audit = build(args.output, args.raw_dir)
    print(json.dumps({k: audit[k] for k in ("status", "start", "end_exclusive", "archive_count", "one_hour", "four_hour_native", "four_hour_crosscheck")}, indent=2))


if __name__ == "__main__":
    main()
